# Cheaper Than Honesty: replication materials

Computational materials for **Cheaper Than Honesty: Minority Coalitions Can
Turn Decentralized AI Evaluation into a Coin Flip**.

The package contains the finite-coalition design programs, saved exact
certificates, fixed-point Python and Rust implementations of the reward
computation, official test fixtures, coalition experiment data, and all three
figure generators. Paths are relative to this directory.

## Quick start

Python 3.11 was used. The first command needs only the standard library:

```sh
python smoke_test.py
python -m pip install -r requirements.txt
python research_ideas/bittensor_paper_b/figures/make_figures.py
```

The smoke test replays 36 official epoch fixtures and compares integer
emissions for the 64 saved canonical coalition profiles and eight permuted
profiles. It also checks the presence of the experiment rows and finite LP
data. It does not run mathematical certificate verification or require Rust.
The last command regenerates Figures 1–3 as PDF and PNG beside the script.
Figures 2 and 3 read the saved numerical data; Figure 1 displays the example
from the introduction.

## Result-to-code map

The common prefix `research_ideas/probes/bittensor/` is abbreviated as
`probes/` in this table only.

| Paper result | Code and saved data |
|---|---|
| Figures 1–3 | `research_ideas/bittensor_paper_b/figures/make_figures.py` |
| Quoted numerical values | `research_ideas/bittensor_paper_b/check_numbers.py` |
| Section 5: finite design without holdings | `probes/coalition_zero_owner.py` and `coalition_phase_probe.py` |
| Example 5.3: the full tolerance interval without holdings and full price domain with holdings | `probes/coalition_global_certificate.py`, `coalition_global_certificate.md`, and `coalition_parametric_probe.json` |
| Proposition 5.4: the three-cutoff example and six restricted optima | `probes/coalition_zero_owner.json` and `coalition_zero_owner.py` |
| Figure 2: finite LP values for 11, 31, and 51 validators | `probes/numerics/phase_finite_lp.csv` and `probes/coalition_phase_probe.json` |
| Two exact finite LP points for 11 validators | `probes/numerics/phase_exact_points.py` and `phase_exact_points.json` |
| Section 7 and Figure 3: the specified coalition policies | `probes/numerics/yuma_phase_probe.py`, `yuma_phase_strategies.csv`, and `yuma_phase_profiles.json` |
| Fixed-point implementations and upstream test coverage | `probes/protocol/` |

All source dependencies for these programs are included. Some supporting
modules retain their original `probe` filenames.

## Finite design and saved certificates

These optional commands recompute the quoted numbers and replay the saved
certificates for Example 5.3 and the two 11-validator points:

```sh
python research_ideas/bittensor_paper_b/check_numbers.py
python research_ideas/probes/bittensor/coalition_global_certificate.py
python research_ideas/probes/bittensor/numerics/phase_exact_points.py --replay
```

The interval certificate command reconstructs the rational constraints and
uses exact real-root isolation. The `--replay` command checks saved rational
primal and dual witnesses without calling an optimizer. These computations
establish their named finite calculations; they do not establish the
economic reduction or the universal asymptotic theorems.

To regenerate the finite LP solutions and the cutoff-example witnesses:

```sh
python research_ideas/probes/bittensor/coalition_phase_probe.py
python research_ideas/probes/bittensor/coalition_zero_owner.py
```

The first command writes the finite optimum values to
`coalition_phase_probe.json`; the figure CSV contains those same values with
display metadata. The second regenerates exact primal and dual certificates
for the unrestricted and restricted small examples. Solver runs and rational
lifting take longer than the quick start. Saved outputs are supplied for
inspection without recomputation.

## Rebuild Rust and rerun the coalition experiment

Follow [the protocol build instructions](research_ideas/probes/bittensor/protocol/README.md)
to fetch the stated upstream sources and build the Rust 1.89.0 reference.
Then run:

```sh
python research_ideas/probes/bittensor/protocol/differential.py
python research_ideas/probes/bittensor/protocol/official_classic.py
python research_ideas/probes/bittensor/protocol/official_extra.py
python research_ideas/probes/bittensor/numerics/yuma_phase_probe.py
python research_ideas/bittensor_paper_b/figures/make_figures.py
```

The coalition experiment uses 31 equal-stake validators, two separate miner
identities, all-or-nothing weights, and uniform starting bonds. It covers
25 accuracies, 15 coalition sizes, two memory settings, two ownership values,
and two specified strategies: 3,000 strategy evaluations in 1,500 parameter
environments. Expectations sum over all relevant binomial counts using
floating-point weights and integer epoch outputs; there is no Monte Carlo
sampling. The script compares 20 canonical or permuted states against Rust.

## Scope and source attribution

- The default-memory experiment counts one epoch from the stated old bonds.
  It does not include the continuation value of future bond payments or
  classify repeated-game equilibria.
- The large-network curves display the theorems under their stated
  assumptions; floating LP solutions and finite grids do not prove them.
- The reference implements resolved epoch-state arithmetic, not a full
  Subtensor node. Registration, scheduling, transaction permissions, and
  dTAO stake conversion remain outside its boundary.
- The recorded 516-input differential comparison establishes agreement on
  those inputs. Coverage counts overlap and should not be added as
  independent samples.

The protocol version is Subtensor commit
`c004cebf360f4088187ee49d851dfb1a1eaaf710`; substrate-fixed is commit
`d5f70362f2e05b5f33fb51cd7baa825323e4e6c5`. Dependency resolution is recorded
in `Cargo.lock`. Attribution and upstream licenses are retained in
[protocol/NOTICE.md](research_ideas/probes/bittensor/protocol/NOTICE.md).

The package excludes account credentials, private project notes, review
records, local Git history, downloaded dependencies, and compiled executables.
