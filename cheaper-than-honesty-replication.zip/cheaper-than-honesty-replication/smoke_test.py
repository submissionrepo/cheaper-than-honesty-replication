"""Replay published software fixtures from an independently extracted package."""
import ast
import copy
import csv
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
PROBES = ROOT / "research_ideas/probes/bittensor"
PROTOCOL = PROBES / "protocol"
NUMERICS = PROBES / "numerics"
sys.path.insert(0, str(PROTOCOL))
from python_epoch import epoch
from differential import first_difference


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def check_profile(state, expected):
    terms = epoch(state)["terms"]
    n = expected["n_validators"]
    reports = [row[0][0] - n for row in state["weights_sparse"][:n]]
    for bit in (0, 1):
        payments = [terms[i]["validator_emission"] for i, vote in enumerate(reports) if vote == bit]
        saved = expected[f"validator_emission_per_report{bit}"]
        assert all(value == saved for value in payments)
        if not payments:
            assert saved == 0
        assert terms[n + bit]["server_emission"] == expected[f"miner{bit}_server_emission"]
    assert sum(t["validator_emission"] for t in terms) == expected["total_validator_emission"]
    assert sum(t["server_emission"] for t in terms) == expected["total_server_emission"]


def main():
    sources = [p for p in ROOT.rglob("*.py")
               if not {".venv", "vendor", "target"}.intersection(p.relative_to(ROOT).parts)]
    for path in sources:
        ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))

    official_count = 0
    for scenario in read_json(PROTOCOL / "official_scenarios.json"):
        for fixture in scenario["fixtures"]:
            actual = json.loads(json.dumps(epoch(fixture["input"])))
            difference = first_difference(actual, fixture["output"])
            assert not difference, (scenario["name"], difference)
            official_count += 1
    assert official_count == 36

    fixtures = read_json(NUMERICS / "yuma_phase_differential_inputs.json")
    profiles = read_json(NUMERICS / "yuma_phase_profiles.json")
    assert len(fixtures) == 20 and len(profiles) == 64
    by_count = {(r["mode"], r["reported_ones"]): r for r in profiles}
    for row in profiles:
        template = next(f["input"] for f in fixtures if f["name"].startswith(row["mode"] + ":"))
        state = copy.deepcopy(template)
        n, k = row["n_validators"], row["reported_ones"]
        state["weights_sparse"] = [[[n + int(i < k), 65535]] for i in range(n)] + [[], []]
        check_profile(state, row)
    permuted = 0
    for fixture in fixtures:
        if ":permuted:" not in fixture["name"]:
            continue
        mode = fixture["name"].split(":")[0]
        state = fixture["input"]
        n = 31
        k = sum(row[0][0] == n + 1 for row in state["weights_sparse"][:n])
        check_profile(state, by_count[mode, k])
        permuted += 1
    assert permuted == 8

    with (NUMERICS / "yuma_phase_strategies.csv").open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    assert len(rows) == 3000
    figure_rows = [r for r in rows if r["strategy"] == "shared_majority_reverse"
                   and r["ownership_total_miner0"] == "0.0" and r["mode"] == "legacy_alpha_one"]
    assert len(figure_rows) == 375
    assert len({r["p"] for r in figure_rows}) == 25
    assert {int(r["coalition_c"]) for r in figure_rows} == set(range(1, 16))
    with (NUMERICS / "phase_finite_lp.csv").open(encoding="utf-8", newline="") as handle:
        finite_rows = list(csv.DictReader(handle))
    assert len(finite_rows) == 15
    assert {int(r["n"]) for r in finite_rows} == {11, 31, 51}

    print(f"Parsed {len(sources)} Python sources; replayed {official_count} official epoch fixtures.")
    print(f"Matched integer emissions for {len(profiles)} canonical and {permuted} permuted coalition profiles.")
    print(f"Loaded {len(rows)} strategy rows and {len(finite_rows)} finite-LP display rows.")
    print("Software smoke test passed; no mathematical certificate verification was run.")


if __name__ == "__main__":
    main()
