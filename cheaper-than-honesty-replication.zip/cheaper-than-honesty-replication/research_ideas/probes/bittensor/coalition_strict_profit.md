# Uniform strict-profit certificates

All coefficients below are recomputed by exact finite binomial sums.
Coordinates are minority payments followed by the constant term.
Split casts one vote per miner without testing; copy buys one test and casts both votes with it.
Both unconditional count distributions are exactly reflection-symmetric, so miner holding income is unchanged.

## n=5, c=2, p=3/4, eta=5/1024, V=1/2

Mixture weights (split, copy): ['15/43', '28/43'].
Gain = 0 * (G-eta) + residual ['0', '3/86', '341/110080'].
Every residual coefficient is nonnegative and its constant exceeds 3/1000 > 0.

## n=7, c=2, p=13/20, eta=316809/89600000, V=1/2

Mixture weights (split, copy): ['0', '1'].
Gain = 7043855/1595187 * (G-eta) + residual ['0', '42490539/590810000', '39276783/472648000', '64128401681/7940486400000'].
Every residual coefficient is nonnegative and its constant exceeds 1/125 > 0.

These identities cover every nonnegative anonymous label-symmetric budget-balanced payment with G>=eta.
They are independent of the allocation and the coalition's holding. Individual feasibility implies G>=eta by the manuscript's IC lemma.
Thus each feasible rule in the quoted examples has a strictly profitable coalition deviation; mixing it into any weakly profitable strategy gives the same damage supremum.
