"""New n=11 phase-plot points with exact primal/dual certificates.

Discovery uses HiGHS. The saved certificates can be replayed without a solver.
This establishes only the two named finite LP values, not an asymptotic theorem.
"""
from pathlib import Path
import argparse
import json
import sys
import time
import sympy as sp

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent))
from coalition_zero_owner import model,solve,lift
from static_frontier_probe import primitives

R=sp.Rational


def replay(data,cert):
    n=len(data['names']);A=list(data['ub']);b=list(data['bub'])
    for i,(lo,hi) in enumerate(data['bounds']):
        for sign,bound in ((-1,lo),(1,hi)):
            if bound is not None:
                row=[R(0)]*n;row[i]=sign;A.append(row);b.append(sign*bound)
    A=sp.Matrix(A);b=sp.Matrix(b);E=sp.Matrix(data['eq']);f=sp.Matrix(data['beq']);c=sp.Matrix(data['c'])
    x=sp.Matrix([R(z) for z in cert['x']]);y=sp.Matrix([R(z) for z in cert['y']])
    ie=cert['dual_eq_indices'];ia=cert['dual_ub_indices']
    assert E*x==f
    assert all(z>=0 for z in b-A*x)
    assert all(z>=0 for z in list(y)[len(ie):])
    assert sp.Matrix.hstack(E[ie,:].T,A[ia,:].T)*y==c
    primal=(c.T*x)[0];dual=(f[ie,:].col_join(b[ia,:]).T*y)[0]
    assert primal==dual==R(cert['quality'])
    return dict(variables=n,equalities=E.rows,inequalities_with_bounds=A.rows,
                minimum_primal_slack=str(min(b-A*x)),primal_dual_gap=str(primal-dual))


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--replay',action='store_true');args=ap.parse_args()
    target=ROOT/'phase_exact_points.json';start=time.time()
    if args.replay:
        rows=json.loads(target.read_text(encoding='utf-8'))
        for row in rows:
            data=model(row['n'],row['c'],R(row['p']),R(row['eta']),R(row['B']))
            replay(data,row['certificate'])
        print('Exact solver-free replay:',len(rows),'finite LP points')
        return
    rows=[]
    # Above both phase boundaries for p=.6, between them for p=.75.
    for n,c,p in ((11,4,R(3,5)),(11,4,R(3,4))):
        eta=primitives(n,p)[2]/4;B=R(1,10)
        data=model(n,c,p,eta,B);ans=solve(data)
        assert ans.success,ans.message
        print('Lifting',n,c,p,flush=True)
        cert=lift(data,ans);checks=replay(data,cert)
        row=dict(n=n,c=c,p=str(p),gamma=str(R(c,n)),eta=str(eta),B=str(B),V='1/2',owner='0',
                 quality=cert['quality'],quality_float=float(R(cert['quality'])),
                 names=data['names'],certificate=cert,replay=checks)
        rows.append(row)
        # Save each successful point before continuing the next.
        target.write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
        print('Exact quality',row['quality'],'=',row['quality_float'],flush=True)
    md=['# 中等人数相图点：有限 LP 的有理证书','',
        '研究计算材料，不是论文证明。两点都为 n=11、c=4、B=1/10、V=1/2、无所有权、eta=G*/4；',
        '支付、分配与连续影子价格在同一零所有权联合设计 LP 中优化。',
        'HiGHS 只用来发现活跃集；保存的有理原始/对偶见证随后由 SymPy 精确回代。','',
        '| p | Q（精确） | Q（显示用小数） | 变量数 | 约束数（含bounds） |',
        '|---|---|---|---|---|']
    for r in rows:
        z=r['replay'];md.append(f"| {r['p']} | {r['quality']} | {r['quality_float']:.12f} | {z['variables']} | {z['equalities']+z['inequalities_with_bounds']} |")
    md += ['', '全部原始可行性、对偶符号、stationarity与零对偶差均按有理数检查。',
           '`phase_exact_points.json` 含全部变量顺序和见证；`python phase_exact_points.py --replay` 不调用求解器。',
           '经济归约、完整偏离空间与渐近相图的正确性不由这两个有限证书建立。',
           f'发现与回代耗时：{time.time()-start:.3f} 秒。']
    (ROOT/'phase_exact_points.md').write_text('\n'.join(md)+'\n',encoding='utf-8')


if __name__=='__main__':main()
