# Source-protocol coalition policy diagnostic run

2026-09-30.

- n=31 validators, two extra miner UIDs, equal effective stake, uniform starting bonds; legacy source branch only.
- Profiles were evaluated by protocol.python_epoch.epoch, not by a majority-sharing replacement formula.
- 64 canonical count profiles cached; 8 additional UID-permuted Python profiles confirmed equal aggregates.
- 20 new profiles matched original Rust EpochTerms and all seven raw traces; failures=0.
- 1500 parameter environments, 3000 specified-policy evaluations, no Monte Carlo draws.
- Maximum binomial mass roundoff=2.220446049250313e-16; profit threshold and damage comparison tolerance=1e-10.
- Numerical margins from the saved strategy rows: {'minimum_displayed_positive_gain': 3.3588817500741774e-06, 'profit_near_zero_count': 0, 'minimum_distance_of_damage_to_B': 0.000717436047236758, 'damage_near_B_count': 0, 'minimum_displayed_damage_excess_above_B': 0.0032143784517786045}.
- Ownership is the coalition total fraction of miner0 emission. Costs use the existing static Gstar/4 calibration with nominal V=1/2.
- Two policies only: no information and constant miner0 reports; all c signals pooled, majority estimated, all reports reversed, random tie.
- Default alpha is the actual fixed-point source alpha for moving_average=900000, and this experiment counts one epoch only.
- No full best-response, equilibrium, absolute safety or complete-capture classification is claimed.
- Category counts: {'legacy_alpha_one:owner=0': {'0': 198, '1': 29, '2': 148}, 'legacy_alpha_one:owner=1/5': {'0': 174, '1': 44, '2': 157}, 'default_fixed_alpha:owner=0': {'0': 0, '1': 213, '2': 162}, 'default_fixed_alpha:owner=1/5': {'0': 0, '1': 213, '2': 162}}
- Original full-run elapsed seconds: 1.488
- Running this script with --summarize refreshes only this JSON/MD numerical-margin summary from the saved CSV; it does not call epoch or Rust.
