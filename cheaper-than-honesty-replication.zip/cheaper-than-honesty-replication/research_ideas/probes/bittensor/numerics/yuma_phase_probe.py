"""Specified coalition policies evaluated through the pinned production epoch.

Every profile payoff comes from protocol.python_epoch.epoch. Expectations use
complete binomial count sums with floating weights, never Monte Carlo. This
diagnostic does not solve equilibria or search the full coalition policy space.
"""
from fractions import Fraction as F
from math import comb,fsum
from pathlib import Path
import csv
import json
import sys
import time

HERE=Path(__file__).resolve().parent
PROTOCOL=HERE.parent/'protocol'
ROOT=HERE.parents[3]
sys.path[:0]=[str(ROOT),str(PROTOCOL)]
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap,BoundaryNorm
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
import matplotlib.patheffects as pe
import hz_figstyle as hz
from python_epoch import epoch
from differential import rust_batch,first_difference

N=31
EMISSION=10**12
P_VALUES=[F(51+2*j,100) for j in range(25)]
C_VALUES=list(range(1,(N+1)//2))
OWNERSHIPS=(F(0),F(1,5))
MODES=(('legacy_alpha_one',0),('default_fixed_alpha',900000))
DAMAGE_B=.1
TOLERANCE=1e-10

def write_csv(name,rows):
    with (HERE/name).open('w',encoding='utf-8',newline='') as fh:
        writer=csv.DictWriter(fh,fieldnames=list(rows[0]))
        writer.writeheader();writer.writerows(rows)

def state_for(reports,moving_average):
    miners=(N,N+1)
    return {'stakes':[10**9]*N+[0,0],
            'weights_sparse':[[[miners[bit],65535]] for bit in reports]+[[],[]],
            'bonds_sparse':[[[miners[0],65535],[miners[1],65535]] for _ in range(N)]+[[],[]],
            'permits':[True]*N+[False,False],'max_validators':N,
            'moving_average':moving_average,'kappa':32767,'bonds_penalty':65535,
            'yuma3':False,'liquid':False,'current_block':110,'last_update':[100]*(N+2),
            'registration':[0]*(N+2),'activity_cutoff':5000,'emission':EMISSION}

def summarize_profile(output,reports):
    terms=output['terms']
    pay={bit:[terms[i]['validator_emission'] for i,z in enumerate(reports) if z==bit] for bit in (0,1)}
    for bit in (0,1):
        if pay[bit] and min(pay[bit])!=max(pay[bit]):
            raise ValueError('Equal-report source payments are not exchangeable in this input family.')
    server0=terms[N]['server_emission'];server1=terms[N+1]['server_emission']
    server_total=server0+server1
    if not server_total:raise ValueError('The declared two-miner experiment unexpectedly has zero server emission.')
    return {'reported_ones':sum(reports),'validator_emission_per_report0':pay[0][0] if pay[0] else 0,
            'validator_emission_per_report1':pay[1][0] if pay[1] else 0,
            'miner0_server_emission':server0,'miner1_server_emission':server1,
            'miner0_allocation_share':server0/server_total,'miner1_allocation_share':server1/server_total,
            'total_validator_emission':sum(t['validator_emission'] for t in terms),
            'total_server_emission':sum(t['server_emission'] for t in terms)}

def source_profiles_and_parity():
    cache={};raw={};all_rows=[];native_cases=[]
    for mode,moving in MODES:
        cache[mode]=[]
        for k in range(N+1):
            reports=[1]*k+[0]*(N-k)
            state=state_for(reports,moving);out=epoch(state)
            summary=summarize_profile(out,reports)
            summary.update(mode=mode,n_validators=N,n_uids=N+2,moving_average=moving)
            cache[mode].append(summary);all_rows.append(summary);raw[mode,k]=(state,out)
        for k in (0,1,15,16,30,31):
            state,out=raw[mode,k]
            native_cases.append((f'{mode}:canonical:{k}',state,out))
        # Deterministic UID permutations, not random signal draws.
        for k in (4,12,19,27):
            reports=[0]*N
            for j in range(k):reports[(7*j+3)%N]=1
            state=state_for(reports,moving);out=epoch(state)
            got=summarize_profile(out,reports)
            for key,value in got.items():
                if cache[mode][k][key]!=value:
                    raise ValueError(f'UID permutation changed cached aggregate {mode,k,key}.')
            native_cases.append((f'{mode}:permuted:{k}',state,out))
    references=rust_batch([state for _,state,_ in native_cases])
    failures=[]
    for (name,state,out),ref in zip(native_cases,references):
        py=json.loads(json.dumps(out))
        diff=first_difference(ref['terms'],py['terms'],'terms') or first_difference(ref['trace'],py['trace'],'trace')
        if diff:failures.append({'name':name,'difference':diff,'input':state,'rust':ref,'python':py})
    if len(references)!=len(native_cases):
        failures.append({'kind':'rust_output_count','expected':len(native_cases),'actual':len(references)})
    (HERE/'yuma_phase_differential_inputs.json').write_text(json.dumps([{'name':name,'input':st} for name,st,_ in native_cases],indent=2),encoding='utf-8')
    (HERE/'yuma_phase_differential_failures.json').write_text(json.dumps(failures,indent=2),encoding='utf-8')
    parity={'profiles':len(native_cases),'failures':len(failures),'canonical':12,'permuted':8,
            'compared':'all EpochTerms and the complete seven-key raw trace dictionary',
            'cached_python_profiles':len(all_rows),'additional_permuted_python_profiles':8,
            'source_commit':'c004cebf360f4088187ee49d851dfb1a1eaaf710'}
    (HERE/'yuma_phase_differential.json').write_text(json.dumps(parity,indent=2),encoding='utf-8')
    if failures:raise RuntimeError('New source-profile differential failed; inspect saved failure file.')
    (HERE/'yuma_phase_profiles.json').write_text(json.dumps(all_rows,indent=2),encoding='utf-8')
    return cache,parity

def binomial_probabilities(m,p):
    return np.array([comb(m,k)*p**k*(1-p)**(m-k) for k in range(m+1)],dtype=float)

def reference_cost(p):
    pf=float(p)
    accuracy=fsum(comb(N,k)*pf**k*(1-pf)**(N-k) for k in range(N//2+1,N+1))
    rent=.5*(2*pf-1)*(accuracy-pf)/(2*N*pf*(1-pf))
    return rent/4,accuracy

def expected_metrics(c,p,profile):
    val0=np.array([r['validator_emission_per_report0']/EMISSION for r in profile])
    val1=np.array([r['validator_emission_per_report1']/EMISSION for r in profile])
    owned=np.array([r['miner0_server_emission']/EMISSION for r in profile])
    shares=[np.array([r[f'miner{j}_allocation_share'] for r in profile]) for j in (0,1)]
    s=np.arange(c+1)[:,None];b=np.arange(N-c+1)[None,:];k=s+b
    coalval=s*val1[k]+(c-s)*val0[k]
    metrics={key:np.zeros(3) for key in ('truthful_reference','constant_miner0','shared_majority_reverse')}
    pmf_error=0.
    for theta in (0,1):
        prob=float(p) if theta else 1-float(p)
        pc=binomial_probabilities(c,prob);po=binomial_probabilities(N-c,prob)
        pmf_error=max(pmf_error,abs(fsum(pc)-1),abs(fsum(po)-1))
        joint=pc[:,None]*po[None,:]
        metrics['truthful_reference']+=.5*np.array([np.sum(joint*coalval),np.sum(joint*owned[k]),np.sum(joint*shares[theta][k])])
        outs=np.arange(N-c+1)
        action0=np.array([np.dot(po,c*val0[outs]),np.dot(po,owned[outs]),np.dot(po,shares[theta][outs])])
        action1=np.array([np.dot(po,c*val1[outs+c]),np.dot(po,owned[outs+c]),np.dot(po,shares[theta][outs+c])])
        metrics['constant_miner0']+=.5*action0
        # Reporting is determined only by the coalition's own acquired count.
        prob_report1=fsum(pc[:(c+1)//2])
        prob_report0=fsum(pc[c//2+1:])
        if c%2==0:
            prob_report1+=pc[c//2]/2;prob_report0+=pc[c//2]/2
        pmf_error=max(pmf_error,abs(prob_report1+prob_report0-1))
        metrics['shared_majority_reverse']+=.5*(prob_report0*action0+prob_report1*action1)
    return metrics,pmf_error

def evaluate(cache):
    strategy_rows=[];cells=[];max_pmf_error=0.
    for mode,moving in MODES:
      for p in P_VALUES:
        eta,accuracy=reference_cost(p)
        for c in C_VALUES:
            metrics,error=expected_metrics(c,p,cache[mode]);max_pmf_error=max(max_pmf_error,error)
            ref_val,ref_owned,ref_quality=metrics['truthful_reference']
            for owner in OWNERSHIPS:
                owner_float=float(owner)
                ref_utility=ref_val+owner_float*ref_owned-c*eta
                candidates=[]
                for strategy in ('constant_miner0','shared_majority_reverse'):
                    acquired=0 if strategy=='constant_miner0' else c
                    val,owned,quality=metrics[strategy]
                    utility=val+owner_float*owned-acquired*eta
                    gain=utility-ref_utility;damage=ref_quality-quality
                    displayed_profit=gain>TOLERANCE
                    over_B=displayed_profit and damage>DAMAGE_B+TOLERANCE
                    row={'mode':mode,'moving_average':moving,'n_validators':N,'n_uids':N+2,
                         'p':float(p),'p_exact':str(p),'coalition_c':c,'gamma':c/N,
                         'ownership_total_miner0':owner_float,'eta':eta,'B':DAMAGE_B,
                         'strategy':strategy,'signals_bought':acquired,'baseline_signals_bought':c,
                         'reference_coalition_validator_income':ref_val,'reference_miner0_income':ref_owned,
                         'reference_quality':ref_quality,'reference_utility':ref_utility,
                         'deviation_coalition_validator_income':float(val),'deviation_miner0_income':float(owned),
                         'deviation_quality':float(quality),'deviation_utility':float(utility),
                         'profit_gain':float(gain),'quality_damage':float(damage),
                         'profit_above_numerical_tolerance':bool(displayed_profit),
                         'profit_and_damage_above_B':bool(over_B),'numerical_tolerance':TOLERANCE,
                         'epoch_source':'protocol.python_epoch.epoch','expectation_method':'complete count sum; floating binomial weights'}
                    strategy_rows.append(row);candidates.append(row)
                profitable=[row for row in candidates if row['profit_above_numerical_tolerance']]
                severe=[row for row in profitable if row['profit_and_damage_above_B']]
                category=2 if severe else 1 if profitable else 0
                selected=max(severe or profitable or candidates,key=lambda row:row['quality_damage'])
                cells.append({'mode':mode,'moving_average':moving,'n_validators':N,'p':float(p),
                              'coalition_c':c,'gamma':c/N,'ownership_total_miner0':owner_float,
                              'category':category,'selected_strategy':selected['strategy'],
                              'selected_profit_gain':selected['profit_gain'],'selected_quality_damage':selected['quality_damage'],
                              'constant_profit':candidates[0]['profit_gain'],'constant_damage':candidates[0]['quality_damage'],
                              'reverse_profit':candidates[1]['profit_gain'],'reverse_damage':candidates[1]['quality_damage'],
                              'eta':eta,'B':DAMAGE_B,'reference_quality':ref_quality})
    write_csv('yuma_phase_strategies.csv',strategy_rows)
    write_csv('yuma_phase_regions.csv',cells)
    return strategy_rows,cells,max_pmf_error

def render(cells):
    hz.apply()
    fig,axes=plt.subplots(2,2,figsize=(6.9,5.65),sharex=True,sharey=True)
    fig.subplots_adjust(wspace=.18,hspace=.25,bottom=.24)
    cmap=ListedColormap(['0.95','0.67','0.28']);norm=BoundaryNorm([-.5,.5,1.5,2.5],3)
    xedges=(np.arange(len(C_VALUES)+1)+.5)/N
    yedges=np.linspace(.5,1,26)
    for ri,(mode,_) in enumerate(MODES):
      for ci,owner in enumerate(OWNERSHIPS):
        ax=axes[ri,ci]
        values=np.array([[next(row['category'] for row in cells if row['mode']==mode and row['ownership_total_miner0']==float(owner)
                               and row['p']==float(p) and row['coalition_c']==c) for c in C_VALUES] for p in P_VALUES])
        ax.pcolormesh(xedges,yedges,values,cmap=cmap,norm=norm,shading='flat',rasterized=False)
        pp=np.linspace(.5,1,251)
        line,=ax.plot(1-1/(2*pp),pp,color='0.08',ls='--',lw=.9)
        line.set_path_effects([pe.Stroke(linewidth=2,foreground='white'),pe.Normal()])
        ax.set_xlim(0,.5);ax.set_ylim(.5,1)
        ax.set_xticks([0,.1,.2,.3,.4,.5]);ax.set_yticks([.5,.6,.7,.8,.9,1])
        ax.grid(False);hz.style_ticklabels(ax)
        alpha_text=r'\alpha=1' if ri==0 else r'\alpha\simeq0.1'
        hz.tag(ax,rf'({chr(97+2*ri+ci)}) ${alpha_text},\ \omega={float(owner):g}$')
        if ci==0:ax.set_ylabel(r'Signal accuracy $p$')
        if ri==1:ax.set_xlabel(r'Coalition fraction $\gamma=c/n$')
    handles=[Patch(facecolor='0.95',edgecolor='0.55',label='No profitable candidate shown'),
             Patch(facecolor='0.67',edgecolor='none',label=r'Profit shown; $D\leq0.1$'),
             Patch(facecolor='0.28',edgecolor='none',label=r'Profit and $D>0.1$ shown'),
             Line2D([0],[0],color='0.08',ls='--',lw=.9,label=r'$\gamma_1$: different asymptotic class')]
    fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.515,.01),ncol=2,frameon=False,
               fontsize=7.7,handlelength=2.2,columnspacing=2.)
    fig.savefig(HERE/'yuma_phase_regions.png',dpi=200,bbox_inches='tight',pad_inches=.03)
    hz.save(fig,HERE/'yuma_phase_regions.pdf')

def numerical_margins(rows):
    """Summarize separation from numerical decision boundaries, without a proof claim."""
    gains=[float(row['profit_gain']) for row in rows]
    damages=[float(row['quality_damage']) for row in rows]
    positive=[gain for gain in gains if gain>TOLERANCE]
    severe=[damage-DAMAGE_B for gain,damage in zip(gains,damages)
            if gain>TOLERANCE and damage>DAMAGE_B+TOLERANCE]
    return {'minimum_displayed_positive_gain':min(positive) if positive else None,
            'profit_near_zero_count':sum(abs(gain)<=TOLERANCE for gain in gains),
            'minimum_distance_of_damage_to_B':min(abs(damage-DAMAGE_B) for damage in damages),
            'damage_near_B_count':sum(abs(damage-DAMAGE_B)<=TOLERANCE for damage in damages),
            'minimum_displayed_damage_excess_above_B':min(severe) if severe else None}

def write_run_summary(result):
    (HERE/'yuma_phase_run.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    lines=['# Source-protocol coalition policy diagnostic run','','2026-09-30.','',
           '- n=31 validators, two extra miner UIDs, equal effective stake, uniform starting bonds; legacy source branch only.',
           '- Profiles were evaluated by protocol.python_epoch.epoch, not by a majority-sharing replacement formula.',
           '- 64 canonical count profiles cached; 8 additional UID-permuted Python profiles confirmed equal aggregates.',
           f"- {result['new_rust_profiles']} new profiles matched original Rust EpochTerms and all seven raw traces; failures={result['new_rust_failures']}.",
           f"- {result['parameter_environments']} parameter environments, {result['strategy_evaluations']} specified-policy evaluations, no Monte Carlo draws.",
           f"- Maximum binomial mass roundoff={result['maximum_binomial_mass_roundoff']}; profit threshold and damage comparison tolerance={TOLERANCE}.",
           f"- Numerical margins from the saved strategy rows: {result['numerical_margins']}.",
           '- Ownership is the coalition total fraction of miner0 emission. Costs use the existing static Gstar/4 calibration with nominal V=1/2.',
           '- Two policies only: no information and constant miner0 reports; all c signals pooled, majority estimated, all reports reversed, random tie.',
           '- Default alpha is the actual fixed-point source alpha for moving_average=900000, and this experiment counts one epoch only.',
           '- No full best-response, equilibrium, absolute safety or complete-capture classification is claimed.',
           f"- Category counts: {result['category_counts']}",
           f"- Original full-run elapsed seconds: {result['elapsed_seconds']:.3f}",
           '- Running this script with --summarize refreshes only this JSON/MD numerical-margin summary from the saved CSV; it does not call epoch or Rust.', '']
    (HERE/'yuma_phase_run.md').write_text('\n'.join(lines),encoding='utf-8')

def refresh_summary():
    result=json.loads((HERE/'yuma_phase_run.json').read_text(encoding='utf-8'))
    with (HERE/'yuma_phase_strategies.csv').open(encoding='utf-8',newline='') as fh:
        result['numerical_margins']=numerical_margins(list(csv.DictReader(fh)))
    write_run_summary(result)
    print(json.dumps({'mode':'saved_csv_summary_only','numerical_margins':result['numerical_margins']},indent=2))

def main():
    start=time.perf_counter()
    cache,parity=source_profiles_and_parity()
    print('New source parity:',parity,flush=True)
    strategies,cells,pmf_error=evaluate(cache)
    render(cells)
    counts={}
    for mode,_ in MODES:
      for owner in OWNERSHIPS:
        chosen=[r for r in cells if r['mode']==mode and r['ownership_total_miner0']==float(owner)]
        counts[f'{mode}:owner={owner}']={str(k):sum(row['category']==k for row in chosen) for k in range(3)}
    emission_loss=max((EMISSION-row['total_server_emission']-row['total_validator_emission'])/EMISSION
                      for profiles in cache.values() for row in profiles)
    result={'date':'2026-09-30','source_commit':parity['source_commit'],'n_validators':N,'n_uids':N+2,
            'stake_per_validator':10**9,'emission_integer':EMISSION,'kappa_u16':32767,'bonds_penalty_u16':65535,
            'yuma3':False,'liquid':False,'old_bonds':'65535 in both miner columns for every validator; uniform after source normalization',
            'p_grid':[str(p) for p in P_VALUES],'coalition_sizes':C_VALUES,'ownership_is_total_coalition_fraction':True,
            'source_profiles_cached':64,'new_python_epoch_calls':72,'new_rust_profiles':parity['profiles'],
            'new_rust_failures':parity['failures'],'parameter_environments':len(cells),'strategy_evaluations':len(strategies),
            'expectations':'complete finite count sums with float binomial weights','monte_carlo_draws':0,
            'profit_and_damage_tolerance':TOLERANCE,'maximum_binomial_mass_roundoff':pmf_error,
            'maximum_total_emission_loss_fraction':emission_loss,'category_counts':counts,
            'numerical_margins':numerical_margins(strategies),
            'new_universal_proof_credential':False,'baseline_claimed_equilibrium':False,
            'default_mode_scope':'one epoch from the stated old bonds; no continuation value',
            'elapsed_seconds':time.perf_counter()-start}
    write_run_summary(result)
    print(json.dumps(result,indent=2),flush=True)

if __name__=='__main__':
    if sys.argv[1:]==['--summarize']:refresh_summary()
    elif sys.argv[1:]:raise SystemExit('Usage: yuma_phase_probe.py [--summarize]')
    else:main()
