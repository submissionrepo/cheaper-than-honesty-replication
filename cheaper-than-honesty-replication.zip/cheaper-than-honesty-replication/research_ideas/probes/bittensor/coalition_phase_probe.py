"""Large-n global zero-owner design and constructive phase probes (discovery)."""
from math import comb,ceil,log
from pathlib import Path
import sys,json
import numpy as np
from scipy.sparse import coo_matrix
from scipy.optimize import linprog
from scipy.special import expit
from scipy.stats import binom
from coalition_zero_owner import model as rational_model,solve as rational_solve,R


def sparse_global(n,c,p,eta,B):
    V=.5;states=[(h,s) for h in range(c+1) for s in range(h+1)]
    mu=3*n+1;L={st:mu+1+j for j,st in enumerate(states)};d=mu+1+len(states)
    a=lambda k:k;z0=lambda k:n+1+k;z1=lambda k:2*n+k
    eq=[];be=[];ub=[];bu=[]
    for k in range(n//2+1):eq.append({a(k):1,a(n-k):1});be.append(1)
    for k in range(n):eq.append({z0(k):1,z1(n-k):-1});be.append(0)
    for k in range(n+1):
        row={mu:-V}
        if k:row[z1(k)]=k
        if k<n:row[z0(k)]=n-k
        eq.append(row);be.append(0)
    for k in range(n):ub.append({a(k):1,a(k+1):-1});bu.append(0)
    weights=(binom.pmf(np.arange(n),n-1,p)+binom.pmf(np.arange(n),n-1,1-p))/2
    row={z0(k):weights[k] for k in range(n)};row[mu]=eta-V/n;ub.append(row);bu.append(0)
    pmfs=[binom.pmf(np.arange(n-c+1),n-c,q) for q in (1-p,p)]
    for h,s in states:
        post=expit((2*s-h)*log(p/(1-p)))
        for j in range(c+1):
            row={L[h,s]:1}
            for theta in (0,1):
                pr=(post if theta else 1-post)*pmfs[theta]
                for out,prob in enumerate(pr):
                    k=j+out;row[a(k)]=row.get(a(k),0)+prob*(-1 if theta else 1)
                    if j:row[z1(k)]=row.get(z1(k),0)+prob*j
                    if c-j:row[z0(k)]=row.get(z0(k),0)+prob*(c-j)
            ub.append(row);bu.append(1-post)
        if h<c:
            one=post*p+(1-post)*(1-p)
            ub.append({L[h,s]:1,L[h+1,s]:-(1-one),L[h+1,s+1]:-one,mu:-eta});bu.append(0)
    quality=binom.pmf(np.arange(n+1),n,p)
    row={a(k):quality[k] for k in range(n+1)};row[L[0,0]]=-1;row[mu]=-c*(V/n-eta);ub.append(row);bu.append(B)
    def matrix(rows):
        rr=[];cc=[];vv=[]
        for i,row in enumerate(rows):
            for j,v in row.items():
                if v:rr.append(i);cc.append(j);vv.append(v)
        return coo_matrix((vv,(rr,cc)),shape=(len(rows),d)).tocsr()
    objective=np.zeros(d);objective[:n+1]=-quality
    bounds=[(0,1)]*(n+1)+[(0,None)]*(2*n+1)+[(None,None)]*len(states)
    ans=linprog(objective,A_eq=matrix(eq),b_eq=be,A_ub=matrix(ub),b_ub=bu,bounds=bounds,method='highs')
    return ans


def probe_mimic(n,p,gamma):
    c=int(gamma*n);N=n-c;r=round(n*(2*p-1))
    # Before clipping J=r+Bin(c,q), the full count has law r+Bin(n,q).
    target=binom.pmf(np.arange(n+1),n,p)
    attack=binom.pmf(np.arange(n+1)-r,n,1-p)
    omitted=1-attack.sum()
    tv=(np.abs(target-attack).sum()+omitted)/2
    clipping=binom.sf(c-r,c,1-p)
    return tv,clipping


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    lines=['# 大n全类设计与两条联盟门槛：方向探针','',
           '候选相图：gamma_1=1-1/(2p)，gamma_2=2-1/p。在n eta_n趋于严格正且低于最大信息租金时，gamma_1两侧先从无损进入Q≤1/2+B；gamma_2之后进一步到Q≤1/2+B/2。浮点LP只检查方向，一般结论需要分布模拟及获利证明。','',
           '| n | c | p | B | global Q | predicted limit |','|---:|---:|---:|---:|---:|---:|']
    data=[]
    for n in (11,31,51):
        for p,gamma in ((.6,.1),(.6,.25),(.6,.45),(.75,.2),(.75,.45)):
            c=max(2,int(n*gamma));A=binom.sf(n//2,n,p)
            G=.5*(2*p-1)*(A-p)/(2*n*p*(1-p));eta=G/4;B=.1
            ans=sparse_global(n,c,p,eta,B);assert ans.success,ans.message
            phase=1 if gamma<1-1/(2*p) else .5+B if gamma<2-1/p else .5+B/2
            row=dict(n=n,c=c,p=p,eta=eta,B=B,Q=-ans.fun,limit=phase)
            data.append(row);lines.append(f'| {n} | {c} | {p} | {B} | {-ans.fun:.10f} | {phase} |')
            print(row,flush=True)
    # New small point cross-check, distinct from previous certificates.
    spoint=sparse_global(7,2,.7,.001,.06)
    rpoint=rational_solve(rational_model(7,2,R(7,10),R(1,1000),R(3,50)))
    assert abs(spoint.fun-rpoint.fun)<1e-9
    lines += ['', '一个新n=7,p=7/10点与有理系数全模型浮点解相同。','',
              '## 反向诚实分布的平移二项式模拟','',
              '| n | p | gamma | total variation | J clipping tail |','|---:|---:|---:|---:|---:|']
    for n in (51,201,1001,10001):
        for p,gamma in ((.6,.45),(.75,.8)):
            tv,cl=probe_mimic(n,p,gamma)
            lines.append(f'| {n} | {p} | {gamma} | {tv:.10g} | {cl:.10g} |')
    Path(__file__).with_suffix('.json').write_text(json.dumps(data,indent=2),encoding='utf-8')
    Path(__file__).with_suffix('.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')


if __name__=='__main__':main()
