"""Integer port of the production sparse Subtensor epoch_mechanism.

Pinned source: c004cebf360f4088187ee49d851dfb1a1eaaf710.
The input boundary supplies effective integer stake and already-resolved active
commit blocks. See python_port_notes.md for scope and test provenance.
"""
from __future__ import annotations

import json
import sys

from python_fixed import (
    F, U64_MAX, add, sub, mul, div, integer, normalise, proportion,
    safe_div, sat, to_u16, uint, wrap, exp_safe,
)


def dense(matrix, n):
    result = [[0] * n for _ in matrix]
    for i, row in enumerate(matrix):
        for j, value in row:
            if 0 <= j < n:
                result[i][j] = value
    return result


def input_sparse(state, key, n):
    if key + "_sparse" in state:
        return [[(int(j), integer(int(v))) for j, v in row]
                for row in state[key + "_sparse"]]
    matrix = state.get(key, [[0] * n for _ in range(n)])
    return [[(j, integer(int(v))) for j, v in enumerate(row) if v != 0]
            for row in matrix]


def row_normalise(matrix):
    result = []
    for row in matrix:
        total = wrap(sum(v for _, v in row))
        result.append([(j, safe_div(v, total) if total > 0 else v) for j, v in row])
    return result


def col_normalise(matrix, n):
    totals = [0] * n
    for row in matrix:
        for j, value in row:
            if 0 <= j < n:
                totals[j] = add(totals[j], value)
    return [[(j, safe_div(v, totals[j]) if 0 <= j < n and totals[j] != 0 else v)
             for j, v in row] for row in matrix]


def col_max_upscale(matrix, n):
    maxima = [0] * n
    for row in matrix:
        for j, value in row:
            if 0 <= j < n:
                maxima[j] = max(maxima[j], value)
    return [[(j, safe_div(v, maxima[j]) if 0 <= j < n and maxima[j] != 0 else v)
             for j, v in row] for row in matrix]


def row_sum(matrix):
    return [wrap(sum(v for _, v in row)) for row in matrix]


def matmul(matrix, vector, n):
    result = [0] * n
    for row, scale in zip(matrix, vector):
        for j, value in row:
            if 0 <= j < n:
                result[j] = add(result[j], mul(scale, value))
    return result


def matmul_transpose(matrix, vector):
    result = []
    for row in matrix:
        value = 0
        for j, cell in row:
            value = add(value, mul(vector[j] if 0 <= j < len(vector) else 0, cell))
        result.append(value)
    return result


def weighted_median(stakes, scores, minority, total):
    """Preserve the source pivot/partition updates, including exact ties."""
    partition = list(range(len(stakes)))
    lo, hi, iterations = 0, total, 0
    while True:
        if not partition:
            return 0
        if len(partition) == 1:
            return scores[partition[0]]
        pivot = scores[partition[len(partition) // 2]]
        lower, upper = [], []
        lo_stake = hi_stake = 0
        for i in partition:
            if scores[i] < pivot:
                lo_stake = add(lo_stake, stakes[i])
                lower.append(i)
            elif scores[i] > pivot:
                hi_stake = add(hi_stake, stakes[i])
                upper.append(i)
        if minority < add(lo, lo_stake) and lower:
            partition, hi = lower, add(lo, lo_stake)
        elif sub(hi, hi_stake) <= minority and upper:
            partition, lo = upper, sub(hi, hi_stake)
        else:
            return pivot
        iterations += 1
        if iterations > len(stakes):
            return 0


def consensus_columns(stakes, matrix, n, majority):
    indices = [i for i, s in enumerate(stakes) if s > 0]
    use_stakes = normalise([stakes[i] for i in indices])
    total = wrap(sum(use_stakes))
    minority = sub(total, majority)
    scores = dense(matrix, n)
    return [weighted_median(use_stakes, [scores[i][j] for i in indices], minority, total)
            for j in range(n)]


def col_clip(matrix, thresholds):
    result = []
    for row in matrix:
        out = []
        for j, value in row:
            threshold = thresholds[j] if 0 <= j < len(thresholds) else 0
            if threshold < value:
                if threshold > 0:
                    out.append((j, threshold))
            else:
                out.append((j, value))
        result.append(out)
    return result


def interpolate(matrix1, matrix2, n, ratio):
    if ratio == 0:
        return [row[:] for row in matrix1]
    if ratio == F:
        return [row[:] for row in matrix2]
    result = []
    for row1, row2 in zip(dense(matrix1, n), dense(matrix2, n)):
        row = []
        for j, (v1, v2) in enumerate(zip(row1, row2)):
            value = add(v1, mul(ratio, sub(v2, v1)))
            if value > 0:
                row.append((j, value))
        result.append(row)
    return result


def ema(new, old, alpha):
    n = len(new)
    result = []
    one_minus = sub(F, alpha)
    for i, new_row in enumerate(new):
        acc = [0] * n
        for j, value in new_row:
            if 0 <= j < n:
                acc[j] = add(acc[j], mul(alpha, value))
        for j, value in old[i]:
            if 0 <= j < n:
                acc[j] = add(acc[j], mul(one_minus, value))
        result.append([(j, v) for j, v in enumerate(acc) if v > 0])
    return result


def alpha_sigmoid(consensus, weight, bond, low, high, steepness):
    diff_buy = min(F, max(0, sub(weight, consensus)))
    diff_sell = min(F, max(0, sub(bond, weight)))
    diff = diff_buy if weight >= bond else diff_sell
    exponent = mul(div(steepness, integer(-100)), sub(diff, F // 2))
    sigmoid = div(F, add(F, exp_safe(exponent)))
    value = add(low, mul(sigmoid, sub(high, low)))
    return max(low, min(high, value))


def liquid_alphas(state, weights, bonds, consensus):
    low = proportion(state.get("alpha_low", 45875))
    high = proportion(state.get("alpha_high", 58982))
    steepness = integer(state.get("steepness", 1000))
    result = []
    # Source traverses its sparse lists with two forward iterators. Retain that
    # behaviour, including explicit zero entries and source ordering.
    for wrow, brow in zip(weights, bonds):
        wi = bi = 0
        alphas = []
        for j, consensus_val in enumerate(consensus):
            while wi < len(wrow) and wrow[wi][0] < j:
                wi += 1
            weight = wrow[wi][1] if wi < len(wrow) and wrow[wi][0] == j else 0
            while bi < len(brow) and brow[bi][0] < j:
                bi += 1
            bond = brow[bi][1] if bi < len(brow) and brow[bi][0] == j else 0
            alphas.append(alpha_sigmoid(consensus_val, weight, bond, low, high, steepness))
        result.append(alphas)
    return result


def ema_alpha(new, old, alphas):
    result = []
    for new_row, old_row, alpha_row in zip(new, old, alphas):
        decayed = [0] * len(alpha_row)
        for j, value in old_row:
            if 0 <= j < len(alpha_row):
                decayed[j] = mul(sub(F, alpha_row[j]), value)
        out = []
        # This deliberately drops old-only entries, exactly as the sparse
        # production function does. A dense EMA is not equivalent here.
        for j, value in new_row:
            if 0 <= j < len(alpha_row):
                increment = max(0, mul(alpha_row[j], value))
                value = min(F, add(decayed[j], increment))
                if value > 0:
                    out.append((j, value))
        result.append(out)
    return result


def epoch(state: dict) -> dict:
    n = len(state["stakes"])
    current = state.get("current_block", 110)
    cutoff = state.get("activity_cutoff", 5000)
    updates = state.get("last_update", [100] * n)
    registration = state.get("registration", [0] * n)
    owner = state.get("owner_uid")
    inactive = [min(U64_MAX, u + cutoff) < current for u in updates]
    active = [not value for value in inactive]

    total_stake = ([int(s) for s in state["stakes_fixed64"]] if "stakes_fixed64" in state
                   else [integer(s, 64, 128) for s in state["stakes"]])
    min_stake = state.get("min_stake", 0)
    filtered = [0 if i != owner and uint(s, 64) < min_stake else s
                for i, s in enumerate(total_stake)]
    stake = [sat(v >> 32) for v in normalise(filtered, 64, 128)]
    permits = list(state.get("permits", [True] * n))
    if owner is not None and 0 <= owner < n:
        permits[owner] = True
    new_permits = [s != 0 for s in stake]
    max_validators = state.get("max_validators", n)
    if n >= max_validators:
        for i in sorted(range(n), key=lambda i: stake[i])[:n - max_validators]:
            new_permits[i] = False
    if owner is not None and 0 <= owner < n:
        new_permits[owner] = True
    active_stake = normalise([s if permits[i] and not inactive[i] else 0
                              for i, s in enumerate(stake)])

    weights = input_sparse(state, "weights", n)
    commits = state.get("commit_blocks", [U64_MAX] * n)
    for i in range(n):
        weights[i] = [(j, v) for j, v in weights[i] if 0 <= j < n
                      and permits[i] and (j != i or owner == i)
                      and updates[i] > registration[j]
                      and (not state.get("commit_reveal", False) or commits[i] >= registration[j])]
    weights = row_normalise(weights)
    consensus = consensus_columns(active_stake, weights, n, proportion(state.get("kappa", 32767)))
    clipped = col_clip(weights, consensus)
    trust = row_sum(clipped)
    incentive = normalise(matmul(clipped, active_stake, n))
    penalty = proportion(state.get("bonds_penalty", 65535))
    weights_for_bonds = interpolate(weights, clipped, n, penalty)

    moving64 = safe_div(integer(state.get("moving_average", 900000), 64, 128),
                        integer(1000000, 64, 128), 64, 128)
    alpha = sub(F, sat(moving64 >> 32))
    bonds = input_sparse(state, "bonds", n)
    if state.get("yuma3", False):
        bonds = [[(j, safe_div(v, integer(65535))) for j, v in row] for row in bonds]
    last_step = state.get("last_step", 0)
    last_tempo = (max(0, current - state.get("tempo", 10)) if last_step == 0
                  else min(U64_MAX, last_step + 1))
    bonds = [[(j, v) for j, v in row if 0 <= j < n and last_tempo > registration[j]]
             for row in bonds]
    if state.get("yuma3", False):
        mode = state.get("consensus_mode", 2)
        use_previous = mode == 1 or (mode != 0 and mode != 1 and penalty == F)
        selected = consensus[:]
        if use_previous and state.get("has_previous_consensus", False):
            previous = state.get("previous_consensus", [0] * n)
            if previous:
                selected = ([proportion(c) for c in previous] + [0] * n)[:n]
        if state.get("liquid", False) and any(selected):
            alphas = liquid_alphas(state, weights_for_bonds, bonds, selected)
            ema_bonds = ema_alpha(weights_for_bonds, bonds, alphas)
        else:
            ema_bonds = ema(weights_for_bonds, bonds, alpha)
        ema_norm = col_normalise(ema_bonds, n)
        totals = matmul_transpose(ema_norm, incentive)
        dividends = normalise([mul(t, s) for t, s in zip(totals, active_stake)])
    else:
        bonds = col_normalise(bonds, n)
        delta = [[(j, mul(v, active_stake[i])) for j, v in row]
                 for i, row in enumerate(weights_for_bonds)]
        delta = col_normalise(delta, n)
        ema_bonds = col_normalise(ema(delta, bonds, alpha), n)
        dividends = normalise(matmul_transpose(ema_bonds, incentive))
        ema_bonds = col_max_upscale(ema_bonds, n)

    combined = [add(ii, di) for ii, di in zip(incentive, dividends)]
    emission_sum = wrap(sum(combined))
    server = normalise(incentive, total=emission_sum)
    validator = normalise(dividends, total=emission_sum)
    combined = normalise(combined)
    if emission_sum == 0:
        validator = (stake if wrap(sum(active_stake)) == 0 else active_stake)[:]
        combined = validator[:]
    emission = state.get("emission", 1000000000)
    terms = []
    for i in range(n):
        terms.append({
            "uid": i,
            "dividend": to_u16(dividends[i]),
            "incentive": to_u16(incentive[i]),
            "validator_emission": uint(mul(validator[i], integer(emission, 32, 128), 32, 128)),
            "server_emission": uint(mul(server[i], integer(emission, 32, 128), 32, 128)),
            "stake_weight": to_u16(stake[i]),
            "active": active[i],
            "emission": uint(mul(combined[i], integer(emission, 32, 128), 32, 128)),
            "consensus": to_u16(consensus[i]),
            "validator_trust": to_u16(trust[i]),
            "new_validator_permit": new_permits[i],
            "bond": [[j, to_u16(v)] for j, v in ema_bonds[i]] if new_permits[i] else [],
            "stake": uint(total_stake[i], 64),
        })
    trace = {
        "normalized_stake": stake,
        "active_stake": active_stake,
        "weights": dense(weights, n),
        "consensus": consensus,
        "clipped_weights": dense(clipped, n),
        "incentive": incentive,
        "dividends": dividends,
    }
    return {"terms": terms, "trace": trace}


if __name__ == "__main__":
    for line in sys.stdin:
        if line.strip():
            print(json.dumps(epoch(json.loads(line)), separators=(",", ":")))
