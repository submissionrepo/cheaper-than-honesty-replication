"""Finite source parity tests; these are software tests, not universal proofs."""
from pathlib import Path
import copy
import json
import random
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
EXE = ROOT / "rust_reference/target/debug" / ("bittensor-epoch-reference" + (".exe" if sys.platform == "win32" else ""))


def rust_batch(cases):
    result = subprocess.run([str(EXE)], input="".join(json.dumps(c) + "\n" for c in cases),
                            capture_output=True, text=True, check=True)
    return [json.loads(line) for line in result.stdout.splitlines()]


def first_difference(a, b, path=""):
    if type(a) is not type(b):
        return path, a, b
    if isinstance(a, dict):
        if a.keys() != b.keys():
            return path + ".keys", sorted(a), sorted(b)
        for k in a:
            d = first_difference(a[k], b[k], path + "." + str(k))
            if d:
                return d
    elif isinstance(a, list):
        if len(a) != len(b):
            return path + ".length", len(a), len(b)
        for k, (x, y) in enumerate(zip(a, b)):
            d = first_difference(x, y, path + "[" + str(k) + "]")
            if d:
                return d
    elif a != b:
        return path, a, b
    return None


def cases():
    rng = random.Random(20260930)
    rows = []
    seed = {"stakes": [33, 33, 34, 0, 0], "weights_sparse": [
        [[3, 65535], [4, 0]], [[3, 0], [4, 65535]], [[3, 30000], [4, 65535]], [], []],
        "bonds_sparse": [[[3, 30000], [4, 65535]], [[3, 10000]], [[4, 60000]], [], []]}
    changes = [({}, "regular"), ({"stakes": [0]*5}, "zero_stake"),
               ({"weights_sparse": [[] for _ in range(5)]}, "zero_weights"),
               ({"weights_sparse": [[[i,65535]] for i in range(5)]}, "diagonal_only"),
               ({"last_update": [0]*5, "activity_cutoff": 2}, "inactive"),
               ({"permits": [False]*5}, "no_permit"),
               ({"last_update": [100]*5,"registration": [0,0,0,100,101]}, "registered"),
               ({"commit_reveal": True,"commit_blocks": [20,50,100,2**64-1,2**64-1],
                 "registration": [0,0,0,50,100]}, "commit_boundary"),
               ({"owner_uid": 0,"permits": [False]*5,"min_stake": 100}, "owner_exception"),
               ({"kappa": 0}, "kappa_zero"), ({"kappa": 65535}, "kappa_one"),
               ({"moving_average": 0}, "alpha_one"), ({"moving_average": 1000000}, "alpha_zero"),
               ({"max_validators": 1}, "permit_changes"),
               ({"emission": 2**64-1}, "emission_u64_max"),
               ({"has_previous_consensus": True,"previous_consensus": [0,1,65535],
                 "consensus_mode": 1}, "previous_resize"),
               ({"has_previous_consensus": True,"previous_consensus": [0]*5,
                 "consensus_mode": 1}, "zero_previous_consensus")]
    for yuma3, liquid in [(False,False),(False,True),(True,False),(True,True)]:
        for patch, name in changes:
            c = copy.deepcopy(seed)
            c.update(patch, yuma3=yuma3, liquid=liquid)
            rows.append((f"edge:{name}:y{int(yuma3)}l{int(liquid)}", c))
        for raw_stake,threshold in [([1,2,3,0,0],0),([2**64-1,2**64,2**64+1,0,0],1),
                                    ([2**125,2**125-1,1,0,0],0)]:
            c=copy.deepcopy(seed)
            c.update(stakes_fixed64=list(map(str,raw_stake)),min_stake=threshold,yuma3=yuma3,liquid=liquid)
            rows.append((f"raw64:{len(rows)}",c))
    for k in range(400):
        n = rng.randrange(1, 15)
        weights = [[rng.randrange(65536) if rng.random() < .55 else 0 for _ in range(n)] for _ in range(n)]
        bonds = [[rng.randrange(65536) if rng.random() < .65 else 0 for _ in range(n)] for _ in range(n)]
        y = bool(k % 2)
        c = dict(stakes=[rng.choice([0, rng.randrange(1,1000000000)]) for _ in range(n)],
                 weights=weights,bonds=bonds,yuma3=y,liquid=bool(k%4>=2),
                 permits=[rng.random() < .8 for _ in range(n)], max_validators=rng.randrange(n+1),
                 min_stake=rng.choice([0,100,100000000]),owner_uid=rng.choice([None,0,n-1]),
                 moving_average=rng.choice([0,500000,900000,975000,1000000]),
                 bonds_penalty=rng.choice([0,32767,65535]), kappa=rng.choice([0,16384,32767,32768,49151,65535]),
                 current_block=110,activity_cutoff=rng.choice([10,5000]),
                 last_update=[rng.choice([0,50,100,110]) for _ in range(n)],
                 registration=[rng.choice([0,20,90,100,105]) for _ in range(n)],
                 commit_reveal=bool(k%3==0),commit_blocks=[rng.choice([50,90,100,2**64-1]) for _ in range(n)],
                 last_step=rng.choice([0,20,100]),consensus_mode=k%3,
                 has_previous_consensus=bool(k%3),previous_consensus=[rng.randrange(65536) for _ in range(n)],
                 steepness=rng.choice([0,100,1000,32767]),
                 alpha_low=rng.choice([1638,6553,45875]),alpha_high=rng.choice([58982,65535]),
                 emission=rng.choice([0,1,10**9,10**15]))
        if k%5==0:
            c["weights_sparse"]=[[[j,v] for j,v in enumerate(r) if v or rng.random()<.2] for r in weights]
            c["bonds_sparse"]=[[[j,v] for j,v in enumerate(r) if v or rng.random()<.2] for r in bonds]
        rows.append((f"random:{k}",c))
    return rows


def main():
    from python_epoch import epoch
    rows = cases()
    for group in json.loads((ROOT/"official_scenarios.json").read_text()):
        for i, fixture in enumerate(group["fixtures"]):
            rows.append((group["name"] + ":" + str(i), fixture["input"]))
    native = rust_batch([c for _, c in rows])
    failures = []
    trace_keys = set()
    for (name, c), ref in zip(rows, native):
        py = epoch(c)
        py = json.loads(json.dumps(py))
        diff = first_difference(ref["terms"], py["terms"], "terms")
        p_trace = py.get("trace", py.get("traces",{}))
        for key in ref["trace"]:
            if key in p_trace:
                trace_keys.add(key)
                diff = diff or first_difference(ref["trace"][key],p_trace[key],"trace."+key)
        if diff:
            failures.append(dict(name=name, input=c, difference=diff, rust=ref, python=py))
    result = dict(count=len(rows), failures=len(failures), shared_trace_keys=sorted(trace_keys),
                  source_commit="c004cebf360f4088187ee49d851dfb1a1eaaf710", seed=20260930)
    (ROOT/"differential_results.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    (ROOT/"differential_failures.json").write_text(json.dumps(failures,indent=2)+"\n",encoding="utf-8")
    (ROOT/"differential_inputs.json").write_text(json.dumps([dict(name=n,input=c) for n,c in rows],indent=2)+"\n",encoding="utf-8")
    print(json.dumps(result,indent=2),flush=True)
    if failures:
        print([(f["name"],f["difference"]) for f in failures[:8]],flush=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
