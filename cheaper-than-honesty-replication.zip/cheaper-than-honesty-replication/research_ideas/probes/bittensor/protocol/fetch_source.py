"""Reproduce the public source checkout used by the standalone parity runner."""
from pathlib import Path
from urllib.request import urlopen
from zipfile import ZipFile
from io import BytesIO
from build_reference import ROOT, COMMIT, FIXED


def fetch(repository, revision):
    data = urlopen(f"https://codeload.github.com/{repository}/zip/{revision}", timeout=180).read()
    dest = ROOT / "vendor"
    dest.mkdir(exist_ok=True)
    with ZipFile(BytesIO(data)) as z:
        for name in z.namelist():
            if not (dest / name).resolve().is_relative_to(dest.resolve()):
                raise ValueError(f"unsafe archive path: {name}")
        z.extractall(dest)
    print(repository, revision, len(data), flush=True)


if __name__ == "__main__":
    for repo, revision in [("opentensor/subtensor", COMMIT), ("encointer/substrate-fixed", FIXED)]:
        if not (ROOT / "vendor" / (repo.split("/")[-1] + "-" + revision)).exists():
            fetch(repo, revision)
