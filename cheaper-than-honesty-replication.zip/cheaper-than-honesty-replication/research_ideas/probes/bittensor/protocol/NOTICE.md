# Upstream source and adaptations

This research directory contains source derived from Subtensor at commit
`c004cebf360f4088187ee49d851dfb1a1eaaf710`, under the Apache License 2.0.
The upstream license is reproduced in `LICENSE.subtensor`.

`rust_reference/src/math.rs`, `safe_math.rs`, `upstream_impl.rs`,
`upstream_math_tests.rs` and `upstream_scenarios.rs` are extracted by the
included build scripts. Imports, state adapters, observation hooks and the
random test's entropy source are adapted as described in
`reference_extraction.json` and `README.md`. The test helper for official
scenario initialization is an adapter, not an unchanged FRAME runtime.

`python_epoch.py` independently expresses the same fixed-point epoch
operations in Python. `python_fixed.py` implements the operations and the
exponential algorithm from substrate-fixed 0.6.0, commit
`d5f70362f2e05b5f33fb51cd7baa825323e4e6c5` (MIT OR Apache-2.0).
Both of that project's license notices are reproduced in
`LICENSE.substrate-fixed.MIT` and `LICENSE.substrate-fixed.APACHE`.

Original projects:

- https://github.com/opentensor/subtensor
- https://github.com/encointer/substrate-fixed

The vendored downloads remain unchanged and are local build dependencies.
This directory is a research reproduction, not an official upstream release.
