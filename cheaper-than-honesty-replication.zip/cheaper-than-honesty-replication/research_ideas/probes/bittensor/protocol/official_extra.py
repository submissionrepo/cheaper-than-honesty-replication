"""Additional state-level ports and complete epoch.rs test inventory.

Only source assertions at the epoch state boundary are replayed. FRAME,
extrinsic, dense-only and direct-helper coverage is reported separately.
"""
from pathlib import Path
import copy
from collections import Counter
import json
import random
import re
import struct
import sys
import time

from differential import rust_batch, first_difference
from python_epoch import epoch, liquid_alphas, ema_alpha, ema
from python_fixed import F, integer, normalise, proportion, safe_div, sub, sat

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "vendor/subtensor-c004cebf360f4088187ee49d851dfb1a1eaaf710/pallets/subtensor/src/tests/epoch.rs"
RUNS, CHECKS, FAILURES = [], [], []
HELPER_RUNS = []


def check(name, label, got, expected, relation="eq"):
    passed = {"eq": lambda: got == expected, "ne": lambda: got != expected, "gt": lambda: got > expected, "lt": lambda: got < expected,
              "ge": lambda: got >= expected, "le": lambda: got <= expected,
              "close": lambda: abs(got - expected) <= .001,
              "close_raw": lambda: abs(got - expected) <= 4294967}[relation]()
    row = dict(test=name, label=label, got=got, expected=expected, relation=relation, passed=passed)
    CHECKS.append(row)
    if not passed:
        FAILURES.append(row)


def f32_raw(value):
    value=struct.unpack("f",struct.pack("f",value))[0]
    numerator,denominator=value.as_integer_ratio()
    return (numerator*F)//denominator


def helper_run(name,state,label):
    rust=rust_batch([state])[0]
    current=state["current32"]
    mode=state.get("consensus_mode",2)
    use_previous=mode==1 or (mode==2 and state.get("bonds_penalty",65535)==65535)
    selected=current[:]
    if use_previous and state.get("has_previous_consensus",False):
        previous=state.get("previous_consensus",[0]*len(state["stakes"]))
        if previous:selected=([proportion(c) for c in previous]+[0]*len(current))[:len(current)]
    weights,bonds=state["weights32"],state["bonds32"]
    alphas=liquid_alphas(state,weights,bonds,selected)
    liquid=ema_alpha(weights,bonds,alphas)
    average=safe_div(integer(state.get("moving_average",900000),64,128),integer(1000000,64,128),64,128)
    fixed=ema(weights,bonds,sub(F,sat(average>>32)))
    python=json.loads(json.dumps(dict(selected32=selected,alphas32=alphas,liquid32=liquid,fixed32=fixed,
                   bonds32=liquid if state.get("liquid",False) and any(selected) else fixed)))
    difference=first_difference({key:rust[key] for key in python},python)
    record=dict(test=name,label=label,sparse_fields_equal=difference is None,input=copy.deepcopy(state))
    if difference:
        record["difference"]=difference;FAILURES.append(record)
    HELPER_RUNS.append(record)
    return rust


def liquid_helpers():
    weights=[0.,.1,0.,0.,.2,.4,0.,.3,.1,0.,.4,.5]
    bonds=[.1,.1,.5,0.,0.,.4,.5,.1,.1,0.,.4,.2]
    def sparse(flat):return [[[j,f32_raw(v)] for j,v in enumerate(flat[i:i+3]) if v] for i in range(0,12,3)]
    current=[f32_raw(v) for v in [.3,.2,.1,.4]]
    state=dict(op="liquid_helpers",stakes=[0]*4,weights32=sparse(weights),bonds32=sparse(bonds),current32=current,
               dense_columns=3,liquid=True,consensus_mode=0,moving_average=900000,alpha_low=45875,alpha_high=58982)

    name="test_liquid_alpha_equal_values_against_itself"
    s=dict(state,alpha_low=6553,alpha_high=6553)
    on=helper_run(name,s,"enabled")
    off=helper_run(name,dict(s,liquid=False),"disabled")
    check(name,"dense-rows",len(on["dense_bonds32"]),len(off["dense_bonds32"]))
    for i,(a,b) in enumerate(zip(on["dense_bonds32"],off["dense_bonds32"])):
        check(name,f"dense-width/{i}",len(a),len(b))
        for j,(x,y) in enumerate(zip(a,b)):
            check(name,f"dense-value/{i}/{j}",abs(x-y),4294967,"le")

    name="test_liquid_alpha_consensus_modes"
    s=dict(state,has_previous_consensus=True,previous_consensus=[6553,13107,21845])
    cur=helper_run(name,s,"current")
    check(name,"current",cur["selected32"],current)
    prev=helper_run(name,dict(s,consensus_mode=1),"previous")
    check(name,"previous-len",len(prev["selected32"]),len(current))
    check(name,"previous-padded",prev["selected32"][3],0)
    check(name,"previous-different",prev["selected32"],current,"ne")
    other=helper_run(name,dict(s,consensus_mode=1,previous_consensus=[32767,16383,8191,4095]),"other-mechanism-post-state")
    check(name,"other-previous-different",other["selected32"],prev["selected32"],"ne")
    middle=helper_run(name,dict(s,consensus_mode=2,bonds_penalty=32767),"auto-middle")
    check(name,"auto-middle",middle["selected32"],current)
    full=helper_run(name,dict(s,consensus_mode=2,bonds_penalty=65535),"auto-full")
    check(name,"auto-full",full["selected32"],prev["selected32"])
    absent=helper_run(name,dict(s,consensus_mode=2,bonds_penalty=65535,has_previous_consensus=False),"no-previous-storage")
    check(name,"no-previous",absent["selected32"],current)

    for sparse_test in [False,True]:
        name="test_compute_bonds"+("_sparse" if sparse_test else "")+"_uses_selected_consensus"
        s=dict(state,has_previous_consensus=True,previous_consensus=[6553,13107,19660,26214])
        key="bonds32" if sparse_test else "dense_bonds32"
        lkey="liquid32" if sparse_test else "dense_liquid32"
        cur=helper_run(name,s,"current")
        check(name,"current-equals-legacy",cur[key],cur[lkey])
        prev=helper_run(name,dict(s,consensus_mode=1),"previous")
        check(name,"previous-differs",cur[key],prev[key],"ne")
        mid=helper_run(name,dict(s,consensus_mode=2,bonds_penalty=32767),"auto-middle")
        check(name,"auto-middle",mid[key],cur[key])
        full=helper_run(name,dict(s,consensus_mode=2,bonds_penalty=65535),"auto-full")
        check(name,"auto-full",full[key],prev[key])

        name="test_compute_bonds"+("_sparse" if sparse_test else "")+"_checks_selected_consensus_for_zero"
        s=dict(s,consensus_mode=1,current32=[0]*4)
        fkey="fixed32" if sparse_test else "dense_fixed32"
        positive=helper_run(name,s,"current-zero-previous-positive")
        check(name,"positive-selected-is-liquid",positive[key],positive[lkey])
        check(name,"positive-selected-not-fixed",positive[key],positive[fkey],"ne")
        zero=helper_run(name,dict(s,current32=current,previous_consensus=[0]*4),"current-positive-previous-zero")
        check(name,"zero-selected-is-fixed",zero[key],positive[fkey])
        check(name,"zero-selected-not-liquid",zero[key],zero[lkey],"ne")

    name="test_min_alpha_low_matches_bonds_moving_average_floor"
    s=dict(op="liquid_helpers",stakes=[0],weights32=[[[0,F]]],bonds32=[[]],current32=[F],
           liquid=False,moving_average=975000,consensus_mode=0)
    output=helper_run(name,s,"alpha-floor")
    alpha=output["fixed32"][0][0][1]
    check(name,"min-alpha-above-fixed-floor",proportion(1639),alpha,"ge")
    check(name,"previous-integer-below-fixed-floor",proportion(1638),alpha,"lt")

    name="test_get_set_alpha"
    for label,value in [("low",1639),("high",65525)]:
        output=helper_run(name,dict(s,liquid=True,alpha_low=value,alpha_high=value),"getter-conversion-"+label)
        raw=output["alphas32"][0][0]
        actual=struct.unpack("f",struct.pack("f",raw/F))[0]
        expected=struct.unpack("f",struct.pack("f",value/65535))[0]
        check(name,label+"-f32-conversion-error",abs(actual-expected),1e-6,"lt")


def run(name, state, step="", store_input=True):
    started = time.perf_counter()
    rust = rust_batch([state])[0]
    python = epoch(state)
    difference = first_difference(rust, python)
    record = dict(test=name, step=str(step), n=len(state["stakes"]),
                  all_terms_and_traces_equal=difference is None,
                  elapsed_seconds=round(time.perf_counter() - started, 4))
    if store_input:
        record["input"] = copy.deepcopy(state)
    if difference:
        record["difference"] = difference
        FAILURES.append(record)
    RUNS.append(record)
    return rust["terms"]


def persist(state, terms):
    state["bonds_sparse"] = [t["bond"] for t in terms]
    state["permits"] = [t["new_validator_permit"] for t in terms]
    state["previous_consensus"] = [t["consensus"] for t in terms]
    state["has_previous_consensus"] = True


def bond(terms, i, j):
    return dict(terms[i]["bond"]).get(j, 0)


def partition(n, validators, interleave):
    if interleave == 0:
        vs = list(range(validators))
    elif interleave == 1:
        vs = list(range(0, n, n // validators))
    else:
        # Upstream uses nondeterministic thread_rng for this permutation.
        # This is one reproducible realization of its arbitrary interleaving.
        perm = list(range(n))
        random.Random(20260930 + n).shuffle(perm)
        vs = perm[:validators]
    return vs, [i for i in range(n) if i not in vs]


def active_stake():
    name = "test_active_stake"
    state = dict(stakes=[1]*4, current_block=1, tempo=1, last_update=[1,1,0,0],
                 weights_sparse=[[[2,65535],[3,65535]],[[2,65535],[3,65535]],[],[]])
    terms = run(name, state, "initial")
    for i in range(4):
        check(name, f"initial/emission/{i}", terms[i]["emission"], 250000000)
        if i < 2:
            check(name, f"initial/dividend/{i}", terms[i]["dividend"], 32767)
            for j in range(4):
                check(name, f"initial/bond/{i}/{j}", bond(terms,i,j), 0 if j < 2 else 65535)
    persist(state, terms)
    state.update(current_block=5002,last_update=[5002,1,0,0])
    terms = run(name,state,"inactive")
    for i,d,e,b in [(0,36044,274999999,65535),(1,29490,224999999,53619)]:
        check(name,f"inactive/dividend/{i}",terms[i]["dividend"],d)
        check(name,f"inactive/emission/{i}",terms[i]["emission"],e)
        for j in [2,3]: check(name,f"inactive/bond/{i}/{j}",bond(terms,i,j),b)
    persist(state,terms)
    state.update(current_block=5003,last_update=[5002,5002,0,0])
    terms=run(name,state,"reactivate")
    for i,d,e,b in [(0,35716,272501132,65535),(1,29818,227498866,54712)]:
        check(name,f"reactivate/dividend/{i}",terms[i]["dividend"],d)
        check(name,f"reactivate/emission/{i}",terms[i]["emission"],e)
        for j in [2,3]: check(name,f"reactivate/bond/{i}/{j}",bond(terms,i,j),b)


def outdated_and_deregistered():
    name="test_outdated_weights"
    state=dict(stakes=[1]*4,current_block=1,tempo=0,last_update=[1]*4,
               weights_sparse=[[[2,65535],[3,32768]],[[2,65535],[3,32768]],[[2,65535]],[[3,65535]]])
    terms=run(name,state,"before-reregister")
    persist(state,terms)
    state.update(stakes=[1,1,1,0],current_block=2,last_update=[2,1,1,1],
                 registration=[0,0,0,1],permits=[True,True,True,False])
    terms=run(name,state,"reregistered")
    check(name,"dividend0",terms[0]["dividend"],32767)
    check(name,"emission0",terms[0]["emission"],250000000)
    check(name,"bond0/2",bond(terms,0,2),65535)
    check(name,"bond0/3",bond(terms,0,3),65535)

    name="test_deregistered_miner_bonds"
    state=dict(stakes=[1]*4,current_block=3,tempo=2,last_update=[1,1,0,0],
               weights_sparse=[[[2,65535],[3,32768]],[[2,65535],[3,32768]],[],[]])
    before=run(name,state,"before-reregister")
    for j in [2,3]:check(name,f"initial/bond0/{j}",bond(before,0,j),0,"gt")
    persist(state,before)
    state.update(stakes=[1,1,1,0],current_block=5,last_update=[4,4,0,4],
                 registration=[0,0,0,4],permits=[True,True,True,False])
    after=run(name,state,"reregistered")
    check(name,"surviving-bond",bond(after,0,2),bond(before,0,2),"ge")
    check(name,"new-uid-bond",bond(after,0,3),bond(before,0,3),"le")


def zero_weights():
    name="test_zero_weights"
    state=dict(stakes=[1,0],current_block=0,tempo=65534,last_update=[0,0],permits=[False,False])
    for step in range(4):
        state["current_block"]=step
        if step==1:state.update(weights_sparse=[[],[[1,65535]]],last_update=[0,1])
        if step==2:state.update(weights_sparse=[[[1,65535]],[]],last_update=[2,1],registration=[0,2])
        if step==3:state.update(last_update=[3,1])
        terms=run(name,state,step)
        expected=[1000000000,0] if step<3 else [500000000,500000000]
        for i in range(2):check(name,f"{step}/emission/{i}",terms[i]["emission"],expected[i])
        persist(state,terms)


def validator_permits():
    name="test_validator_permits"
    for interleave in range(3):
        for n,nv in [(2,1),(4,2),(8,4)]:
            vs,ss=partition(n,nv,interleave)
            for assignment in [0,1]:
                stakes=[(i+n if assignment else 1) if i in vs else (i if assignment else 0) for i in range(n)]
                state=dict(stakes=stakes,tempo=65534,current_block=0,last_update=[0]*n,
                           permits=[False]*n,max_validators=nv,min_stake=nv)
                terms=run(name,state,f"i{interleave}/n{n}/a{assignment}/initial")
                for i in range(n):check(name,f"i{interleave}/n{n}/a{assignment}/initial/{i}",terms[i]["new_validator_permit"],i in vs and stakes[i]>=nv)
                persist(state,terms)
                state.update(stakes=[s+2*n if i in ss else s for i,s in enumerate(stakes)],current_block=1)
                terms=run(name,state,f"i{interleave}/n{n}/a{assignment}/switch")
                for i in range(n):check(name,f"i{interleave}/n{n}/a{assignment}/switch/{i}",terms[i]["new_validator_permit"],i in ss and state["stakes"][i]>=nv)


def owner_commit_and_mismatch():
    name="test_can_set_self_weight_as_subnet_owner"
    state=dict(stakes=[5000000000000,0],owner_uid=0,permits=[True,False],current_block=1,
               last_update=[2,0],weights_sparse=[[[0,32767],[1,32767]],[]])
    terms=run(name,state)
    check(name,"output-length",len(terms),2)
    for i in range(2):check(name,f"positive-server/{i}",terms[i]["server_emission"],0,"gt")
    check(name,"equal-server",terms[0]["server_emission"],terms[1]["server_emission"])

    name="test_epoch_masks_incoming_to_sniped_uid_prevents_inheritance"
    state=dict(stakes=[10000,10000,5000],current_block=23,tempo=10,commit_reveal=True,
               commit_blocks=[21,2**64-1,2**64-1],registration=[0,22,0],last_update=[23,22,0],
               permits=[True,True,True],weights_sparse=[[[0,65535],[1,65535]],[],[]],emission=1000)
    terms=run(name,state,"post-registration-state")
    check(name,"sniped-incentive",terms[1]["incentive"],0)

    name="test_epoch_does_not_mask_outside_window_but_masks_inside"
    state=dict(stakes=[10000,1000,1000,1000],current_block=34,tempo=8,commit_reveal=True,
               commit_blocks=[32,2**64-1,2**64-1,2**64-1],registration=[0,8,33,33],
               last_update=[34,8,33,33],permits=[True,False,False,False],max_validators=1,
               weights_sparse=[[[1,65535],[2,65535],[3,65535]],[],[],[]],emission=1000)
    terms=run(name,state)
    check(name,"old-uid-positive",terms[1]["incentive"],0,"gt")
    for i in [2,3]:check(name,f"new-uid-masked/{i}",terms[i]["incentive"],0)

    # The official CR-disabled test checks stored weights, which epoch never
    # writes; reproduce the three epoch calls but do not relabel storage reads.
    name="test_epoch_no_mask_when_commit_reveal_disabled"
    state=dict(stakes=[1000,1000],current_block=0,tempo=5,commit_reveal=False,
               last_update=[0,0],permits=[True,False],weights_sparse=[[[1,65535]],[]],emission=1)
    for step in range(3):
        state["current_block"]=step*6
        terms=run(name,state,step)
        persist(state,terms)

    name="test_last_update_size_mismatch"
    terms=run(name,dict(stakes=[1000000000],current_block=1,tempo=65534,
                        last_update=[1,1,1],weights_sparse=[[[0,65535]]]))
    for field in ["consensus","incentive","dividend"]:check(name,field,terms[0][field],0)


def bonds_reset():
    name="test_yuma_3_bonds_reset"
    state=dict(stakes=[8,1,1,0,0],current_block=110,last_update=[100]*5,max_validators=3,
               permits=[True,True,True,False,False],yuma3=True,liquid=True,bonds_penalty=0,
               alpha_low=6553,alpha_high=19660,steepness=1000,moving_average=975000)
    targets={0:[.8000,.1000,.1000,0,0],1:[.8944,.0528,.0528,0,0],2:[.5230,.2385,.2385,0,0],
             19:[.7919,.1040,.1040,0,0],20:[.7928,.1036,.1036,0,0],21:[.8467,.0766,.0766,0,0],40:[.7928,.1036,.1036,0,0]}
    for step in range(41):
        if step==0 or step>21:reports=[[65535,0]]*3
        elif step==1:reports=[[65535,0],[0,65535],[0,65535]]
        elif step==21:reports=[[0,65535],[65535,0],[65535,0]]
        else:reports=[[0,65535]]*3
        state["weights_sparse"]=[[[3,r[0]],[4,r[1]]] for r in reports]+[[],[]]
        if step==20:
            # do_reset_bonds is a storage transform outside epoch. Its exact
            # post-state (delete column 3 from every old row) is supplied here.
            state["bonds_sparse"]=[[[j,v] for j,v in row if j!=3] for row in state["bonds_sparse"]]
        terms=run(name,state,step)
        if step in targets:
            for i,t in enumerate(targets[step]):
                check(name,f"epoch{step}/dividend/{i}",proportion(terms[i]["dividend"]),f32_raw(t),"close_raw")
        persist(state,terms)


def graph512():
    name="test_512_graph"
    n,nv=512,64
    for interleave in range(3):
        vs,ss=partition(n,nv,interleave)
        for self_weight in [False,True]:
            weights=[([[j,65535] for j in ss] if i in vs else ([[i,65535]] if self_weight else [])) for i in range(n)]
            state=dict(stakes=[328125000000000 if i in vs else 0 for i in range(n)],current_block=1,
                       tempo=65534,last_update=[1 if i in vs or self_weight else 0 for i in range(n)],
                       permits=[i in vs for i in range(n)],max_validators=nv,weights_sparse=weights)
            for step in range(3):
                terms=run(name,state,f"i{interleave}/self{int(self_weight)}/epoch{step}",False)
                persist(state,terms)
            for i in range(n):
                validator=i in vs
                for field,target in [("consensus",0 if validator else 146),("incentive",0 if validator else 146),
                                     ("dividend",1023 if validator else 0),("emission",7812500 if validator else 1116071)]:
                    check(name,f"i{interleave}/self{int(self_weight)}/{i}/{field}",terms[i][field],target)
                check(name,f"i{interleave}/self{int(self_weight)}/{i}/bond-validator",bond(terms,i,vs[0]),0)
                check(name,f"i{interleave}/self{int(self_weight)}/{i}/bond-server",bond(terms,i,ss[0]),65535 if validator else 0)


def strip_comments(text):
    text=re.sub(r"/\*.*?\*/",lambda m:"\n"*m.group().count("\n"),text,flags=re.S)
    return re.sub(r"//[^\n]*","",text)


def inventory():
    raw=SOURCE.read_text(encoding="utf-8")
    text=strip_comments(raw)
    tests=[]
    for m in re.finditer(r"#\[test\]\s*fn\s+(\w+)\s*\(\)\s*\{",text):
        start=m.end();level=1;end=start
        while level and end<len(text):
            level+=(text[end]=="{")-(text[end]=="}");end+=1
        body=text[start:end-1]
        assertions=[]
        for a in re.finditer(r"\b(assert(?:_eq|_ne|_ok|_err|_abs_diff_eq)?!|assert_mat_compare)\s*\(",body):
            pos=a.end();depth=1;finish=pos
            while depth and finish<len(body):
                depth+=(body[finish]=="(")-(body[finish]==")");finish+=1
            assertions.append(dict(line=text[:start+a.start()].count("\n")+1,macro=a.group(1),text=" ".join(body[a.start():finish].split())))
        tests.append(dict(name=m.group(1),line=text[:m.start()].count("\n")+2,source_assertions=assertions))
    return tests


def coverage(tests):
    existing={"test_1_graph","test_10_graph","test_bonds","test_epoch_outputs_single_staker_registered_no_weights"}
    scenarios=json.loads((ROOT/"official_scenarios.json").read_text(encoding="utf-8"))
    existing.update(s["name"] for s in scenarios)
    replayed={r["test"] for r in RUNS}
    helper_tests={r["test"] for r in HELPER_RUNS}
    reasons={
        "test_512_graph_random_weights":"Original assertion compares dense epoch against sparse epoch under Rust StdRng. The reference deliberately runs production sparse only; no claim of original dense/sparse test replay.",
        "test_set_alpha_disabled":"FRAME origin/owner authorization and LiquidAlphaDisabled dispatch error; no epoch invocation.",
        "test_min_alpha_low_matches_bonds_moving_average_floor":"Configuration default and setter clamp assertions; no epoch invocation.",
        "test_get_set_alpha":"Alpha storage getters, authorization and parameter validation errors; outside supplied-state epoch boundary.",
        "test_blocks_since_last_step":"on_initialize/automatic epoch scheduling and block-counter storage; outside single epoch mathematical entry.",
        "test_liquid_alpha_equal_values_against_itself":"Dense compute_bonds helper assertion on a rectangular raw fixed-point matrix; dense helper not exposed by sparse epoch reference.",
        "test_liquid_alpha_consensus_modes":"Direct consensus selector and cross-mechanism storage isolation; single-mechanism epoch entry does not expose original helper assertions.",
        "test_compute_bonds_uses_selected_consensus":"Dense compute_bonds/EMA helper assertion; dense path deliberately not substituted for production sparse path.",
        "test_compute_bonds_sparse_uses_selected_consensus":"Direct sparse helper on rectangular raw fixed-point input; not exposed by epoch state entry, so end-to-end mode probes are not relabelled original assertions.",
        "test_compute_bonds_checks_selected_consensus_for_zero":"Dense helper-only zero-selection assertions; outside production sparse epoch entry.",
        "test_compute_bonds_sparse_checks_selected_consensus_for_zero":"Direct sparse helper-only zero-selection assertions; end-to-end fallback probes exist separately but are not these original assertions.",
        "regression_liquid_alpha_event_indices_are_append_only":"SCALE event discriminants, outside numerical epoch.",
        "empty_ok":"is_epoch_input_state_consistent checks FRAME Keys map; runner assumes unique UID/hotkey map by construction.",
        "unique_hotkeys_and_uids_ok":"is_epoch_input_state_consistent checks FRAME Keys map; runner supplies one unique hotkey per UID.",
        "duplicate_hotkey_within_same_netuid_fails":"Duplicate FRAME hotkeys cannot be represented by current unique-UID mathematical input.",
        "same_hotkey_across_different_netuids_is_ok":"Cross-netuid Keys storage isolation, outside single-network mathematical input.",
    }
    for test in tests:
        name=test["name"]
        test["executed_epochs"]=sum(r["test"]==name for r in RUNS)
        test["executed_helper_calls"]=sum(r["test"]==name for r in HELPER_RUNS)
        test["executed_source_expectation_checks"]=sum(c["test"]==name for c in CHECKS)
        if name in existing:
            test.update(status="covered_in_existing_material",reason="See official_classic_results.json or official_scenarios.json; FRAME setup assertions excluded there.")
        elif name in helper_tests:
            dense_only=name in {"test_liquid_alpha_equal_values_against_itself","test_compute_bonds_uses_selected_consensus","test_compute_bonds_checks_selected_consensus_for_zero"}
            if name in {"test_min_alpha_low_matches_bonds_moving_average_floor","test_get_set_alpha"}:
                test.update(status="numeric_conversion_assertions_replayed_setup_excluded",reason="Only original fixed-alpha floor/conversion numeric assertions replayed through source helper; setters, origin checks, storage round trips and dispatch errors remain excluded.")
            elif dense_only:
                test.update(status="dense_helper_original_assertions_rust_only",reason="Original 4x3 fixed-point dense helper expectations replayed by Rust original functions; NOT a Python dense port. Related sparse outputs independently compared to Python on every helper call.")
            else:
                test.update(status="sparse_helper_assertions_replayed",reason="Original fixed-point matrices, selection branches and equality/inequality expectations replayed; five sparse raw outputs compared to Python.")
                if name=="test_liquid_alpha_consensus_modes":
                    test["reason"]+=" Other-mechanism previous vector is supplied as a second state; this checks selection values, not FRAME cross-mechanism storage isolation."
        elif name in replayed:
            test.update(status="state_boundary_replayed",reason="All epoch outputs/traces compared; only the listed numerical source expectations replayed. Registration, account identity, configuration storage and extrinsic assertions remain adapter assumptions.")
            if name=="test_epoch_no_mask_when_commit_reveal_disabled":
                test.update(status="epoch_calls_replayed_storage_assertion_excluded",reason="Original checks get_weights_sparse storage remains nonempty, not masked epoch weights. Epoch output does not persist weights; do not turn this into a stronger effective-weight assertion.")
            if name=="test_yuma_3_bonds_reset":
                test["reason"]+=" Reset storage transform supplied explicitly. Original helper's bond zip skips all short target rows, so only dividend target assertions are active; all resulting bond bytes still compared across implementations."
        else:
            test.update(status="outside_current_entry_not_replayed",reason=reasons.get(name,"UNCLASSIFIED"))
        for a in test["source_assertions"]:
            statement=a["text"]
            if name in existing:
                a.update(status="delegated_existing_material",reason=test["reason"])
            elif name in helper_tests:
                if a["macro"] in {"assert_ok!","assert_err!"}:
                    a.update(status="not_replayed_dispatch",reason="Parameter validation, authorization and FRAME dispatch are outside supplied helper state.")
                elif name=="test_get_set_alpha" and "grabbed_alpha" in statement:
                    a.update(status="not_replayed_storage_roundtrip",reason="Alpha values storage setter/getter round-trip is supplied by adapter, not executed.")
                else:
                    a.update(status=test["status"],reason=test["reason"])
            elif name not in replayed:
                a.update(status="not_replayed",reason=test["reason"])
            elif a["macro"] in {"assert_ok!","assert_err!"}:
                a.update(status="not_replayed_dispatch",reason="Registration/staking/set_weights/reveal-period dispatch and origin checks are prior to the supplied-state mathematical boundary.")
            elif any(s in statement for s in ["get_max_allowed_uids","get_subnetwork_n","get_max_registrations_per_block","get_registrations_this_block","get_max_allowed_validators"]):
                a.update(status="not_replayed_configuration_storage",reason="FRAME registration/configuration storage; represented by supplied n/max_validators without testing the setter or storage getter.")
            elif "get_total_stake_for_hotkey" in statement:
                a.update(status="not_replayed_stake_storage",reason="Upstream staking storage assertion, not the effective stake conversion performed by epoch.")
            elif any(s in statement for s in ["get_rank_for_uid","get_trust_for_uid"]):
                a.update(status="not_replayed_legacy_storage",reason="Rank/trust storage getters are not emitted or persisted by current EpochTerms; do not relabel incentive/trust trace checks as these storage assertions.")
            elif "get_weights_sparse" in statement:
                a.update(status="not_replayed_weight_storage",reason="Original assertion is on unmodified stored weights, not effective masked weights; epoch runner does not emulate the persistence layer.")
            elif any(s in statement for s in ["System::block_number","get_hotkey_for_net_and_uid","block_at_registration >=","hk =="]):
                a.update(status="not_replayed_registration_identity",reason="Block progression, re-registration selection, or AccountId identity is supplied by the state adapter rather than executed.")
            else:
                a.update(status="state_expectation_replayed",reason="Numeric epoch expectation expanded over the source test loops; see checks for concrete values.")
    return tests


def main():
    started=time.perf_counter()
    functions=[active_stake,outdated_and_deregistered,zero_weights,validator_permits,owner_commit_and_mismatch,bonds_reset,graph512,liquid_helpers]
    if "--helpers-only" in sys.argv:
        prior=json.loads((ROOT/"official_extra_results.json").read_text(encoding="utf-8"))
        RUNS.extend(prior["epoch_runs"])
        retained=[c for c in prior["checks"] if c["test"] not in {r["test"] for r in prior.get("helper_runs",[])}]
        # Early run stored this helper's u16/65535 comparison in floats. Recover
        # the exact observed u16 (range <=65535) and replay the actual fixed/f32
        # assertion without repeating any already-passing epoch execution.
        for c in retained:
            if c["test"]=="test_yuma_3_bonds_reset" and c["relation"]=="close":
                c["got"]=proportion(round(c["got"]*65535))
                c["expected"]=f32_raw(c["expected"])
                c["relation"]="close_raw"
                c["passed"]=abs(c["got"]-c["expected"])<=4294967
                if not c["passed"]:FAILURES.append(c)
        CHECKS.extend(retained)
        FAILURES.extend(prior["failures"])
        functions=[liquid_helpers]
    for fn in functions:
        try:fn()
        except Exception as exc:
            FAILURES.append(dict(group=fn.__name__,exception=repr(exc)))
        print(fn.__name__,len(RUNS),"epochs",len(CHECKS),"checks",len(FAILURES),"failures",flush=True)
    tests=coverage(inventory())
    result=dict(source_commit="c004cebf360f4088187ee49d851dfb1a1eaaf710",test_inventory=tests,
                epoch_runs=RUNS,helper_runs=HELPER_RUNS,checks=CHECKS,failures=FAILURES,
                elapsed_seconds=round(time.perf_counter()-started,3))
    (ROOT/"official_extra_results.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    summary=dict(source_commit=result["source_commit"],formal_test_functions=len(tests),
                 source_assertion_sites=sum(len(t["source_assertions"]) for t in tests),
                 extra_epoch_comparisons=len(RUNS),sparse_helper_comparisons=len(HELPER_RUNS),
                 expanded_numeric_expectation_checks=len(CHECKS),failures=len(FAILURES),
                 tests_by_status=dict(Counter(t["status"] for t in tests)),
                 assertions_by_status=dict(Counter(a["status"] for t in tests for a in t["source_assertions"])),
                 per_test=[{k:v for k,v in t.items() if k!="source_assertions"} for t in tests],
                 full_suite_claim=False)
    (ROOT/"official_extra_summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    with (ROOT/"official_extra_run.log").open("a",encoding="utf-8") as handle:
        handle.write(json.dumps(dict(timestamp=time.strftime("%Y-%m-%d %H:%M:%S"),mode="helpers-only" if "--helpers-only" in sys.argv else "all",epochs=len(RUNS),helper_calls=len(HELPER_RUNS),checks=len(CHECKS),failures=FAILURES),ensure_ascii=False)+"\n")
    md=["# Additional official epoch test coverage", "", "Research software evidence only; not a full FRAME suite pass.", "",
        f"Formal test functions: {len(tests)}. Additional epoch comparisons: {len(RUNS)}. Helper calls: {len(HELPER_RUNS)}. Replayed numerical expectation checks: {len(CHECKS)}. Findings: {len(FAILURES)}.","",
        "| Source test | Status | Epochs | Numeric checks | Scope/reason |","| --- | --- | ---: | ---: | --- |"]
    for t in tests:md.append(f"| `{t['name']}` (line {t['line']}) | {t['status']} | {t['executed_epochs']} | {t['executed_source_expectation_checks']} | {t['reason']} |")
    md += ["", "Every source assertion macro and its line/text is inventoried in `official_extra_results.json`; setup/adapter assertions are preserved as coverage exclusions, not counted as passed. The check list identifies the numerical assertions actually executed.", "", "Large uniform graph replay uses the original n=512, 64 validators and all three interleaving modes, two server-self settings, and three epochs. The upstream random interleaving is unseeded; this replay chooses one reproducible permutation. Original random-weight dense-versus-sparse test remains separately excluded.", "", "Outputs are compared for all EpochTerms and seven raw traces, including bond values even when an upstream helper accidentally skips its target bond loop. These finite tests do not prove universal equivalence."]
    if FAILURES:md += ["","## Findings", "", "```json",json.dumps(FAILURES,ensure_ascii=False,indent=2),"```"]
    md += ["", "## Assertion-level coverage", "", "The following inventory lists the disposition of every assertion macro (and direct matrix comparison) inside the 38 formal test functions. A pass at the state boundary does not cover excluded setup, identity, or storage assertions."]
    for test in tests:
        md += ["",f"### {test['name']}","", "| Source line | Assertion status | Reason |", "| ---: | --- | --- |"]
        if not test["source_assertions"]:
            md.append("| — | expectations delegated to test helper | See the test-level row and executed check list. |")
        for a in test["source_assertions"]:
            md.append(f"| {a['line']} | {a['status']} | {a['reason']} |")
    (ROOT/"official_extra_coverage.md").write_text("\n".join(md)+"\n",encoding="utf-8")
    print(json.dumps(dict(tests=len(tests),epochs=len(RUNS),checks=len(CHECKS),failures=len(FAILURES))))
    if FAILURES:
        raise SystemExit(1)


if __name__=="__main__":main()
