#![allow(dead_code, unused_imports)]
extern crate alloc;
mod math;
mod safe_math;
mod scenarios;
#[cfg(test)]
mod upstream_math_tests;
use math::*;
use safe_math::*;
use serde::Serialize;
use serde_json::{Value, json};
use std::{cell::RefCell, collections::{BTreeMap, BTreeSet}, io::{self, BufRead}, marker::PhantomData};
use substrate_fixed::types::{I32F32, I64F64, I96F32};

type NetUid = u16;
type MechId = u16;
type NetUidStorageIndex = u16;
type AlphaBalance = u64;
trait Config { type AccountId: Ord + Copy + From<u16> + std::fmt::Debug; }
struct Runtime;
impl Config for Runtime { type AccountId = u16; }
struct Pallet<T>(PhantomData<T>);
struct EpochOutput<T: Config>(BTreeMap<T::AccountId, EpochTerms>);
#[derive(Debug, Default, Serialize)]
struct EpochTerms {
    uid: usize, dividend: u16, incentive: u16, validator_emission: u64,
    server_emission: u64, stake_weight: u16, active: bool, emission: u64,
    consensus: u16, validator_trust: u16, new_validator_permit: bool,
    bond: Vec<(u16,u16)>, stake: u64,
}
#[derive(Clone, Copy)]
struct PerU16(u16);
impl PerU16 { fn deconstruct(self)->u16 {self.0} }
enum ConsensusMode { Current, Previous, Auto }
thread_local! {
    static STATE: RefCell<Value> = RefCell::new(json!({}));
    static TRACE: RefCell<serde_json::Map<String,Value>> = RefCell::new(Default::default());
}
fn val(k:&str)->Value { STATE.with(|s| s.borrow()[k].clone()) }
fn num(k:&str,d:u64)->u64 { val(k).as_u64().unwrap_or(d) }
fn flag(k:&str,d:bool)->bool {val(k).as_bool().unwrap_or(d)}
fn len()->usize {val("stakes").as_array().unwrap().len()}
fn arr(k:&str,d:u64)->Vec<u64> {val(k).as_array().map(|a|a.iter().map(|v|v.as_u64().unwrap()).collect()).unwrap_or(vec![d;len()])}
fn bools(k:&str,d:bool)->Vec<bool> {val(k).as_array().map(|a|a.iter().map(|v|v.as_bool().unwrap()).collect()).unwrap_or(vec![d;len()])}
fn sparse(k:&str)->Vec<Vec<(u16,u16)>> {
    if let Some(a)=val(&format!("{k}_sparse")).as_array() {
        return a.iter().map(|r|r.as_array().unwrap().iter().map(|v|(v[0].as_u64().unwrap() as u16,v[1].as_u64().unwrap() as u16)).collect()).collect();
    }
    val(k).as_array().map(|a|a.iter().map(|r|r.as_array().unwrap().iter().enumerate().filter_map(|(j,v)|{
        let x=v.as_u64().unwrap() as u16; if x==0 {None} else {Some((j as u16,x))}
    }).collect()).collect()).unwrap_or(vec![vec![];len()])
}
fn trace32(k:&str,v:&[I32F32]) {TRACE.with(|t|t.borrow_mut().insert(k.to_owned(),json!(v.iter().map(|x|x.to_bits()).collect::<Vec<_>>())));}
fn tracesparse(k:&str,v:&[Vec<(u16,I32F32)>]) {
    let mut a=vec![vec![0_i64;len()];v.len()]; for(i,r)in v.iter().enumerate(){for(j,x)in r{a[i][*j as usize]=x.to_bits();}}
    TRACE.with(|t|t.borrow_mut().insert(k.to_owned(),json!(a)));
}
struct Keys<T>(PhantomData<T>);
impl<T:Config> Keys<T>{
    fn iter_prefix(_:u16)->std::vec::IntoIter<(u16,T::AccountId)>{(0..len() as u16).map(|i|(i,i.into())).collect::<Vec<_>>().into_iter()}
    fn contains_key(_:u16,i:u16)->bool{(i as usize)<len()}
}
struct Weights<T>(PhantomData<T>);
struct Bonds<T>(PhantomData<T>);
impl<T> Weights<T>{fn iter_prefix(_:u16)->std::vec::IntoIter<(u16,Vec<(u16,u16)>)>{sparse("weights").into_iter().enumerate().map(|(i,r)|(i as u16,r)).collect::<Vec<_>>().into_iter()}}
impl<T> Bonds<T>{fn iter_prefix(_:u16)->std::vec::IntoIter<(u16,Vec<(u16,u16)>)>{sparse("bonds").into_iter().enumerate().map(|(i,r)|(i as u16,r)).collect::<Vec<_>>().into_iter()}}
struct Yuma3On<T>(PhantomData<T>);
impl<T> Yuma3On<T>{fn get(_:u16)->bool{flag("yuma3",false)}}
struct LiquidAlphaOn<T>(PhantomData<T>);
impl<T> LiquidAlphaOn<T>{fn get(_:u16)->bool{flag("liquid",false)}}
struct LastMechansimStepBlock<T>(PhantomData<T>);
impl<T> LastMechansimStepBlock<T>{fn get(_:u16)->u64{num("last_step",0)}}
struct ConsensusByMechanism<T>(PhantomData<T>);
impl<T> ConsensusByMechanism<T>{fn get(_:u16)->Vec<PerU16>{
    if !flag("has_previous_consensus",false){return vec![];}
    arr("previous_consensus",0).into_iter().map(|x|PerU16(x as u16)).collect()
}}
struct WeightCommits<T>(PhantomData<T>);
impl<T:Config> WeightCommits<T>{fn iter_prefix(_:u16)->std::vec::IntoIter<(T::AccountId,Vec<(u8,u64,u64,u8)>)>{
    arr("commit_blocks",u64::MAX).into_iter().enumerate().filter_map(|(i,b)|if b==u64::MAX{None}else{Some(((i as u16).into(),vec![(0,0,b,0)]))}).collect::<Vec<_>>().into_iter()
}}
struct TimelockedWeightCommits<T>(PhantomData<T>);
impl<T:Config> TimelockedWeightCommits<T>{fn iter_prefix(_:u16)->std::vec::IntoIter<(u64,Vec<(T::AccountId,u64,u8)>)>{vec![].into_iter()}}
impl<T:Config> Pallet<T>{
    fn get_mechanism_storage_index(n:u16,_:u16)->u16{n}
    fn get_netuid_and_subid(n:u16)->Option<(u16,u16)>{Some((n,0))}
    fn get_netuid(n:u16)->u16{n}
    fn get_subnetwork_n(_:u16)->u16{len() as u16}
    fn get_current_block_as_u64()->u64{num("current_block",110)}
    fn get_tempo(_:u16)->u16{num("tempo",10) as u16}
    fn get_activity_cutoff_blocks(_:u16)->u64{num("activity_cutoff",5000)}
    fn get_last_update(_:u16)->Vec<u64>{arr("last_update",100)}
    fn get_neuron_block_at_registration(_:u16,i:u16)->u64{arr("registration",0)[i as usize]}
    fn get_stake_weights_for_network(_:u16)->(Vec<I64F64>,Vec<I64F64>,Vec<I64F64>){
        if let Some(a)=val("stakes_fixed64").as_array(){
            return (a.iter().map(|v|I64F64::from_bits(v.as_str().map(|s|s.parse::<i128>().unwrap()).unwrap_or_else(||v.as_i64().unwrap() as i128))).collect(),vec![],vec![]);
        }
        (arr("stakes",0).into_iter().map(I64F64::saturating_from_num).collect(),vec![],vec![])
    }
    fn get_stake_threshold()->u64{num("min_stake",0)}
    fn get_owner_uid(_:u16)->Option<u16>{val("owner_uid").as_u64().map(|v|v as u16)}
    fn get_validator_permit(_:u16)->Vec<bool>{bools("permits",true)}
    fn get_max_allowed_validators(_:u16)->u16{num("max_validators",len() as u64) as u16}
    fn get_commit_reveal_weights_enabled(_:u16)->bool{flag("commit_reveal",false)}
    fn is_commit_expired(_:u16,_:u64)->bool{false} // input has already resolved active commits
    fn get_kappa(_:u16)->u16{num("kappa",32767) as u16}
    fn get_bonds_penalty(_:u16)->u16{num("bonds_penalty",65535) as u16}
    fn get_bonds_moving_average(_:u16)->u64{num("moving_average",900000)}
    fn get_liquid_alpha_consensus_mode(_:u16)->ConsensusMode{match num("consensus_mode",2){0=>ConsensusMode::Current,1=>ConsensusMode::Previous,_=>ConsensusMode::Auto}}
    fn get_alpha_sigmoid_steepness(_:u16)->I32F32{I32F32::from_num(val("steepness").as_i64().unwrap_or(1000))}
    fn get_alpha_values_32(_:u16)->(I32F32,I32F32){(u16_proportion_to_fixed(num("alpha_low",45875) as u16),u16_proportion_to_fixed(num("alpha_high",58982) as u16))}
}
include!("upstream_impl.rs");
fn helper_input(k:&str)->Vec<Vec<(u16,I32F32)>> {
    val(k).as_array().unwrap().iter().map(|r|r.as_array().unwrap().iter().map(|v|
        (v[0].as_u64().unwrap() as u16,I32F32::from_bits(v[1].as_i64().unwrap()))
    ).collect()).collect()
}
fn helper_bits(v:&[Vec<(u16,I32F32)>])->Value {
    json!(v.iter().map(|r|r.iter().map(|(j,x)|(*j,x.to_bits())).collect::<Vec<_>>()).collect::<Vec<_>>())
}
fn dense_bits(v:&[Vec<I32F32>])->Value {
    json!(v.iter().map(|r|r.iter().map(|x|x.to_bits()).collect::<Vec<_>>()).collect::<Vec<_>>())
}
fn liquid_helpers()->Value {
    let current=val("current32").as_array().unwrap().iter().map(|x|I32F32::from_bits(x.as_i64().unwrap())).collect::<Vec<_>>();
    let weights=helper_input("weights32");let bonds=helper_input("bonds32");
    let selected=Pallet::<Runtime>::compute_consensus_for_liquid_alpha(1,&current);
    let alphas=Pallet::<Runtime>::compute_liquid_alpha_values_sparse(1,&weights,&bonds,&selected);
    let alpha=Pallet::<Runtime>::compute_disabled_liquid_alpha(1);
    let columns=num("dense_columns",current.len() as u64) as usize;
    let mut dw=vec![vec![I32F32::from_num(0);columns];weights.len()];
    let mut db=vec![vec![I32F32::from_num(0);columns];bonds.len()];
    for(i,row)in weights.iter().enumerate(){for(j,x)in row{dw[i][*j as usize]=*x;}}
    for(i,row)in bonds.iter().enumerate(){for(j,x)in row{db[i][*j as usize]=*x;}}
    let da=Pallet::<Runtime>::compute_liquid_alpha_values(1,&dw,&db,&selected);
    json!({"selected32":selected.iter().map(|x|x.to_bits()).collect::<Vec<_>>(),
           "bonds32":helper_bits(&Pallet::<Runtime>::compute_bonds_sparse(1,&weights,&bonds,&current)),
           "alphas32":dense_bits(&alphas),
           "liquid32":helper_bits(&mat_ema_alpha_sparse(&weights,&bonds,&alphas)),
           "fixed32":helper_bits(&mat_ema_sparse(&weights,&bonds,alpha)),
           "dense_bonds32":dense_bits(&Pallet::<Runtime>::compute_bonds(1,&dw,&db,&current)),
           "dense_liquid32":dense_bits(&mat_ema_alpha(&dw,&db,&da)),
           "dense_fixed32":dense_bits(&mat_ema(&dw,&db,alpha))})
}
fn main(){
    for line in io::stdin().lock().lines(){
        let line=line.unwrap(); if line.trim().is_empty(){continue;}
        let input:Value=serde_json::from_str(&line).unwrap();
        if input["op"]=="official_scenarios" {println!("{}",scenarios::run_all());continue;}
        STATE.with(|s|*s.borrow_mut()=input); TRACE.with(|t|t.borrow_mut().clear());
        if val("op")=="liquid_helpers" {println!("{}",liquid_helpers());continue;}
        let out=Pallet::<Runtime>::epoch_mechanism(1,0,num("emission",1_000_000_000));
        let trace=TRACE.with(|t|t.borrow().clone());
        println!("{}",json!({"terms":out.0.into_values().collect::<Vec<_>>(),"trace":trace}));
    }
}
