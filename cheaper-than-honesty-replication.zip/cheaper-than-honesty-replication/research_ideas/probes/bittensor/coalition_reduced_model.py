"""Eliminate anonymous budget equalities; enumerate c=2 adaptive policies."""
from dataclasses import dataclass
from itertools import product
from math import comb
import numpy as np
import sympy as sp
from scipy.optimize import linprog

R=sp.Rational


@dataclass
class Reduced:
    n:int
    p:object
    eta:object
    omega:object
    V:object=R(1,2)
    M:object=R(1,2)

    def __post_init__(self):
        self.m=self.n//2;self.d=self.n
        self.alloc=[];self.v0=[];self.v1=[]
        zero=lambda:sp.zeros(1,self.d+1)
        for k in range(self.n+1):
            a=zero()
            if k<=self.m:a[k]=1
            else:a[0,self.d]=1;a[self.n-k]=-1
            self.alloc.append(a)
            if k==0:
                v=zero();v[0,self.d]=self.V/self.n;self.v0.append(v);self.v1.append(zero())
            elif k==self.n:
                v=zero();v[0,self.d]=self.V/self.n;self.v1.append(v);self.v0.append(zero())
            elif k<=self.m:
                one=zero();one[self.m+k]=1
                other=zero();other[0,self.d]=self.V/(self.n-k);other[self.m+k]=-R(k,self.n-k)
                self.v1.append(one);self.v0.append(other)
            else:
                self.v1.append(self.v0[self.n-k]);self.v0.append(self.v1[self.n-k])
        self.quality=zero();self.G=zero();self.G[0,self.d]=self.V/self.n;self.H=zero()
        for k in range(self.n+1):self.quality+=R(comb(self.n,k))*self.p**k*(1-self.p)**(self.n-k)*self.alloc[k]
        for k in range(self.n):
            pr=R(comb(self.n-1,k))*(self.p**k*(1-self.p)**(self.n-1-k)+(1-self.p)**k*self.p**(self.n-1-k))/2
            self.G-=pr*self.v0[k]
            self.H+=R(comb(self.n-1,k))*self.p**k*(1-self.p)**(self.n-1-k)*(self.alloc[k+1]-self.alloc[k])
        self.bounds=[(R(0),R(1,2))]*(self.m+1)+[(R(0),self.V/k) for k in range(1,self.m+1)]
        self.order=[]
        for k in range(self.m):
            row=zero();row[k]=1;row[k+1]=-1;self.order.append(row)
        self.individual=-self.G+self.omega*self.M*self.H/2
        self.individual[0,self.d]+=self.eta
        self.policies=self.enumerate_policies()

    def stop(self,h,s,j):
        post=self.p**s*(1-self.p)**(h-s)/(self.p**s*(1-self.p)**(h-s)+(1-self.p)**s*self.p**(h-s))
        q=sp.zeros(1,self.d+1);u=sp.zeros(1,self.d+1)
        for theta in (0,1):
            one=self.p if theta else 1-self.p
            posterior=post if theta else 1-post
            for outside in range(self.n-1):
                prob=posterior*comb(self.n-2,outside)*one**outside*(1-one)**(self.n-2-outside)
                k=j+outside
                val=(j*self.v1[k] if j else sp.zeros(1,self.d+1))+((2-j)*self.v0[k] if j<2 else sp.zeros(1,self.d+1))
                alloc=self.alloc[k]
                qual=alloc.copy() if theta else -alloc
                if not theta:qual[0,self.d]+=1
                q+=prob*qual;u+=prob*(val+self.omega*self.M*alloc)
        return q,u

    def enumerate_policies(self):
        level={}
        for h in (2,1,0):
            for s in range(h+1):
                choices=[(j,*self.stop(h,s,j)) for j in range(3)]
                if h<2:
                    post=self.p**s*(1-self.p)**(h-s)/(self.p**s*(1-self.p)**(h-s)+(1-self.p)**s*self.p**(h-s))
                    one=post*self.p+(1-post)*(1-self.p)
                    for left,right in product(level[h+1,s],level[h+1,s+1]):
                        q=(1-one)*left[1]+one*right[1];u=(1-one)*left[2]+one*right[2];u[0,self.d]-=self.eta
                        choices.append((('buy',left[0],right[0]),q,u))
                unique={tuple(q)+tuple(u):(name,q,u) for name,q,u in choices}
                level[h,s]=list(unique.values())
        truth=self.V*2/self.n+self.omega*self.M/2-2*self.eta
        result=[]
        for name,q,u in level[0,0]:
            gain=u.copy();gain[0,self.d]-=truth
            damage=self.quality-q
            result.append((name,damage,gain))
        return result

    def matrices(self,B,mu):
        rows=self.order+[self.individual]+[damage+mu*gain for _,damage,gain in self.policies]
        rhs=[R(0)]*(len(self.order)+1)+[B]*len(self.policies)
        A=sp.Matrix.vstack(*(row[:,:self.d] for row in rows));b=sp.Matrix([r-row[0,self.d] for r,row in zip(rhs,rows)])
        return A,b

    def solve(self,B,mu):
        A,b=self.matrices(B,mu)
        obj=-self.quality[:,:self.d]
        ans=linprog(np.array(obj,float).ravel(),A_ub=np.array(A,float),b_ub=np.array(b,float).ravel(),bounds=self.bounds,method='highs')
        if not ans.success:return None
        return float(self.quality[0,self.d])-ans.fun,ans,A,b

    def owner_zero_matrices(self,B):
        assert self.omega==0
        d=self.d;rows=[];rhs=[]
        # Variables: original allocations, scaled minority payments, and mu.
        for row in self.order:
            rows.append(list(row[:,:d])+[R(0)]);rhs.append(-row[0,d])
        row=list(-self.G[:,:d])+[self.eta-self.G[0,d]];rows.append(row);rhs.append(R(0))
        for _,damage,gain in self.policies:
            row=[]
            for k in range(d):
                if k<=self.m:
                    assert gain[k]==0
                    row.append(damage[k])
                else:
                    assert damage[k]==0
                    row.append(gain[k])
            row.append(gain[0,d]);rows.append(row);rhs.append(B-damage[0,d])
        for k in range(1,self.m+1):
            row=[R(0)]*(d+1);row[self.m+k]=1;row[-1]=-self.V/k;rows.append(row);rhs.append(R(0))
        bounds=[(R(0),R(1,2))]*(self.m+1)+[(R(0),None)]*(self.m+1)
        obj=list(-self.quality[:,:d])+[R(0)]
        return sp.Matrix(rows),sp.Matrix(rhs),obj,bounds

    def solve_owner_zero_perspective(self,B):
        A,b,obj,bounds=self.owner_zero_matrices(B)
        ans=linprog(np.array(obj,float),A_ub=np.array(A,float),b_ub=np.array(b,float).ravel(),bounds=bounds,method='highs')
        if not ans.success:return None
        return float(self.quality[0,self.d])-ans.fun,ans,A,b,obj,bounds
