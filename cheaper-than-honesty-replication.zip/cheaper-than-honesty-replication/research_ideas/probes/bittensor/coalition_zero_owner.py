"""Global zero-owner coalition design LP, including the shadow price."""
from math import comb
from itertools import combinations
from pathlib import Path
import sys,json
import numpy as np
import sympy as sp
from scipy.optimize import linprog
from static_frontier_probe import primitives

R=sp.Rational


def model(n,c,p,eta,B,V=R(1,2),support=None):
    states=[(h,s) for h in range(c+1) for s in range(h+1)]
    names=[f'a{k}' for k in range(n+1)]+[f'z0{k}' for k in range(n)]+[f'z1{k}' for k in range(1,n+1)]+['mu']+[f'L{h}_{s}' for h,s in states]
    ix={name:i for i,name in enumerate(names)};d=len(names)
    zero=lambda:[R(0)]*d
    eq=[];beq=[];ub=[];bub=[]
    for k in range(n//2+1):
        row=zero();row[ix[f'a{k}']]=1;row[ix[f'a{n-k}']]=1;eq.append(row);beq.append(R(1))
    for k in range(n):
        row=zero();row[ix[f'z0{k}']]=1;row[ix[f'z1{n-k}']]=-1;eq.append(row);beq.append(R(0))
    for k in range(n+1):
        row=zero();row[ix['mu']]=-V
        if k:row[ix[f'z1{k}']]=k
        if k<n:row[ix[f'z0{k}']]=n-k
        eq.append(row);beq.append(R(0))
    for k in range(n):
        row=zero();row[ix[f'a{k}']]=1;row[ix[f'a{k+1}']]=-1;ub.append(row);bub.append(R(0))
    if support is not None:
        for k in range(n//2+1):
            if k not in support:
                row=zero();row[ix[f'a{k}']]=1;row[ix[f'a{k+1}']]=-1;eq.append(row);beq.append(R(0))
    row=zero();row[ix['mu']]=eta-V/n
    for k in range(n):
        row[ix[f'z0{k}']]=R(comb(n-1,k))*(p**k*(1-p)**(n-1-k)+(1-p)**k*p**(n-1-k))/2
    ub.append(row);bub.append(R(0))
    for h,s in states:
        post=p**s*(1-p)**(h-s)/(p**s*(1-p)**(h-s)+(1-p)**s*p**(h-s))
        for j in range(c+1):
            row=zero();row[ix[f'L{h}_{s}']]=1
            for theta in (0,1):
                one=p if theta else 1-p;pt=post if theta else 1-post
                for out in range(n-c+1):
                    prob=pt*comb(n-c,out)*one**out*(1-one)**(n-c-out);k=j+out
                    row[ix[f'a{k}']]+=prob*(-1 if theta else 1)
                    if j:row[ix[f'z1{k}']]+=prob*j
                    if c-j:row[ix[f'z0{k}']]+=prob*(c-j)
            ub.append(row);bub.append(1-post)
        if h<c:
            one=post*p+(1-post)*(1-p);row=zero()
            row[ix[f'L{h}_{s}']]=1;row[ix[f'L{h+1}_{s}']]=-(1-one);row[ix[f'L{h+1}_{s+1}']]=-one;row[ix['mu']]=-eta
            ub.append(row);bub.append(R(0))
    quality=zero()
    for k in range(n+1):quality[ix[f'a{k}']]=R(comb(n,k))*p**k*(1-p)**(n-k)
    row=list(quality);row[ix['L0_0']]=-1;row[ix['mu']]=-c*(V/n-eta);ub.append(row);bub.append(B)
    bounds=[(R(0),R(1))]*(n+1)+[(R(0),None)]*(2*n+1)+[(None,None)]*len(states)
    return dict(names=names,eq=eq,beq=beq,ub=ub,bub=bub,bounds=bounds,c=quality)


def solve(data):
    return linprog(-np.array(data['c'],float),A_eq=np.array(data['eq'],float),b_eq=np.array(data['beq'],float),
                   A_ub=np.array(data['ub'],float),b_ub=np.array(data['bub'],float),bounds=data['bounds'],method='highs')


def lift(data,ans):
    """Return exact primal and dual with full feasibility and zero gap."""
    d=len(data['names']);A=list(data['ub']);b=list(data['bub'])
    for i,(lo,hi) in enumerate(data['bounds']):
        for sign,bound in ((-1,lo),(1,hi)):
            if bound is not None:
                row=[R(0)]*d;row[i]=sign;A.append(row);b.append(sign*bound)
    A=sp.Matrix(A);b=sp.Matrix(b);E=sp.Matrix(data['eq']);f=sp.Matrix(data['beq']);c=sp.Matrix(data['c'])
    # Fresh numerical solve uses exactly the expanded inequality form.
    ans=linprog(-np.array(c,float).ravel(),A_eq=np.array(E,float),b_eq=np.array(f,float).ravel(),
                A_ub=np.array(A,float),b_ub=np.array(b,float).ravel(),bounds=[(None,None)]*d,method='highs')
    assert ans.success
    active=[i for i,s in enumerate(ans.ineqlin.residual) if abs(s)<1e-8]
    rows=E.col_join(A[active,:]);rhs=f.col_join(b[active,:])
    xx,params=rows.gauss_jordan_solve(rhs)
    if params.rows:xx=xx.subs({z:0 for z in params})
    assert E*xx==f and all(z>=0 for z in b-A*xx)
    ie=[i for i,z in enumerate(ans.eqlin.marginals) if abs(z)>1e-10]
    ia=[i for i,z in enumerate(ans.ineqlin.marginals) if abs(z)>1e-10]
    mat=sp.Matrix.hstack(E[ie,:].T,A[ia,:].T)
    yy,params=mat.gauss_jordan_solve(c)
    if params.rows:yy=yy.subs({z:0 for z in params})
    assert all(z>=0 for z in list(yy)[len(ie):])
    assert mat*yy==c
    assert (f[ie,:].col_join(b[ia,:]).T*yy)[0]==(c.T*xx)[0]
    return dict(quality=str((c.T*xx)[0]),x=list(map(str,xx)),dual_eq_indices=ie,dual_ub_indices=ia,y=list(map(str,yy)))


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    lines=['# 无所有权少数联盟：全价格联合设计','',
           '使用z=mu*v，将影子价格、支付与分配在一个LP里同时优化。这里的质量是整个连续价格域的最优值；浮点发现与随后精确证书分开。','']
    cases=[]
    for n,c,p,B in ((5,2,R(3,4),R(1,20)),(7,2,R(3,5),R(1,20)),(7,3,R(3,5),R(1,20)),(9,4,R(3,5),R(1,100)),(11,5,R(3,4),R(1,10)),(7,2,R(13,20),R(3,100))):
        eta=primitives(n,p)[2]/(2 if p==R(13,20) else 4);data=model(n,c,p,eta,B);ans=solve(data);assert ans.success
        k=[j for j in range(n//2+1) if ans.x[j+1]-ans.x[j]>1e-7]
        restricted=[]
        for support in combinations(range(n//2+1),2):
            sub=model(n,c,p,eta,B,support=support);ss=solve(sub)
            if ss.success:restricted.append((-ss.fun,support))
        best=max(restricted)
        lines.append(f'- n={n},c={c},p={p},eta={eta},B={B}: Q={-ans.fun:.12g}, 非零门槛={k}, 最佳两门槛={best}.')
        cases.append((n,c,p,eta,B,data,ans,best))
    certificates=[]
    for n,c,p,eta,B,data,ans,best in cases:
        if n==7 and c==2:
            cert=lift(data,ans);restricted=[]
            for support in combinations(range(n//2+1),2):
                sub=model(n,c,p,eta,B,support=support);ss=solve(sub);assert ss.success
                restricted.append(dict(support=list(support),**lift(sub,ss)))
            compared=restricted if p==R(13,20) else [z for z in restricted if n//2 in z['support']]
            top=max(R(z['quality']) for z in compared)
            assert R(cert['quality'])>top
            out=dict(n=n,c=c,p=str(p),eta=str(eta),B=str(B),unrestricted=cert,two_thresholds=restricted,comparison='all pairs' if p==R(13,20) else 'central plus one',
                     exact_gap=str(R(cert['quality'])-top))
            certificates.append(out)
            lines += ['', '## 门槛猜想的完整有理反例证书', '',
                      f'p={p}，比较类={out["comparison"]}：全类Q={cert["quality"]}，受限类上界={top}，严格差={out["exact_gap"]}。',
                      '全类与六个支持限制的原始可行性、对偶非负、stationarity和目标相等均经有理回代；JSON保存全部见证。']
    Path(__file__).with_suffix('.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    Path(__file__).with_suffix('.json').write_text(json.dumps(certificates,indent=2),encoding='utf-8')
    print('\n'.join(lines))


if __name__=='__main__':main()
