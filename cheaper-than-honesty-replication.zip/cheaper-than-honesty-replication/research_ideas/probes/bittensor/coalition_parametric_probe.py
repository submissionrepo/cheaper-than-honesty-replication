"""Rational primal/dual bases for the continuous coalition price domain.

Floating solvers choose candidate bases. All bounds and objectives are then
reconstructed over Q(mu); no sampled sign is used to cover an interval.
"""
from pathlib import Path
import sys
import json
import numpy as np
import sympy as sp
from scipy.optimize import linprog
from coalition_reduced_model import Reduced,R

mu=sp.symbols('mu',real=True)


def with_bounds(model,B):
    A,b=model.matrices(B,mu)
    rows=list(A.tolist());rhs=list(b)
    for i,(lo,hi) in enumerate(model.bounds):
        if lo is not None:
            row=[R(0)]*model.d;row[i]=-1;rows.append(row);rhs.append(-lo)
        if hi is not None:
            row=[R(0)]*model.d;row[i]=1;rows.append(row);rhs.append(hi)
    return sp.Matrix(rows),sp.Matrix(rhs)


def basis_at(model,A,b,sample):
    aa=np.array(A.subs(mu,sample),float);bb=np.array(b.subs(mu,sample),float).ravel()
    c=model.quality[:,:model.d].T
    ans=linprog(-np.array(c,float).ravel(),A_ub=aa,b_ub=bb,bounds=[(None,None)]*model.d,method='highs')
    if not ans.success:return None
    active=[i for i,s in enumerate(ans.ineqlin.residual) if abs(s)<1e-7]
    active.sort(key=lambda i:ans.ineqlin.marginals[i])
    chosen=[];rank=0
    for i in active:
        newrank=np.linalg.matrix_rank(aa[chosen+[i],:],tol=1e-9)
        if newrank>rank:chosen.append(i);rank=newrank
        if rank==model.d:break
    assert rank==model.d
    mat=A[chosen,:]
    xx=(mat.inv()*b[chosen,:]).applyfunc(sp.cancel)
    yy=(mat.T.inv()*c).applyfunc(sp.cancel)
    slacks=(b-A*xx).applyfunc(sp.factor)
    assert all(z.subs(mu,sample)>=0 for z in (*slacks,*yy))
    assert (mat.T*yy-c).applyfunc(sp.cancel)==sp.zeros(model.d,1)
    q=sp.factor((c.T*xx)[0]+model.quality[0,model.d])
    return dict(basis=chosen,x=xx,y=yy,slacks=slacks,q=q)


def roots_from(expressions):
    factors=set()
    for exp in expressions:
        if exp==0:continue
        numerator,denominator=sp.fraction(sp.cancel(exp))
        for poly in (numerator,denominator):
            for factor,_ in sp.factor_list(poly,mu)[1]:
                if sp.degree(factor,mu)>0:factors.add(sp.Poly(factor,mu).monic().as_expr())
    roots=[]
    for f in factors:
        for root in sp.polys.polytools.real_roots(f,mu):
            if root>=0 and root not in roots:roots.append(root)
    return sorted(roots,key=lambda z:float(z.evalf(25)))


def valid_component(cert,sample):
    roots=roots_from([*cert['slacks'],*cert['y']])
    edges=[sp.S.Zero]+[r for r in roots if r>0]+[sp.oo]
    loc=next(i for i in range(len(edges)-1) if edges[i]<sample<edges[i+1])
    def inside(lo,hi):
        if hi is sp.oo:z=sp.ceiling(lo)+1
        else:
            z=R(str(float((lo+hi).evalf(20)/2)))
            assert lo<z<hi
        return all(s.subs(mu,z)>=0 for s in (*cert['slacks'],*cert['y']))
    lower=loc;upper=loc
    while lower>0 and inside(edges[lower-1],edges[lower]):lower-=1
    while upper<len(edges)-2 and inside(edges[upper+1],edges[upper+2]):upper+=1
    return edges[lower],edges[upper+1],roots


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    model=Reduced(5,R(3,4),R(5,1024),R(1));B=R(1,20)
    A,b=with_bounds(model,B)
    seen=set();certs=[]
    for sample in map(R,['.005','.03','.1','.11','.12','.1237','.13','.2','.4','.6','.8','1','3','8','12','16','20']):
        cert=basis_at(model,A,b,sample)
        if cert is None:
            print('infeasible at',sample,flush=True);continue
        key=tuple(cert['basis'])
        if key in seen:continue
        seen.add(key)
        lo,hi,roots=valid_component(cert,sample)
        print('basis',cert['basis'],'domain',lo,hi,'q',cert['q'],flush=True)
        certs.append(dict(sample=str(sample),basis=cert['basis'],lower=str(lo),upper=str(hi),q=str(cert['q']),
                          x=list(map(str,cert['x'])),y=list(map(str,cert['y']))))
    Path(__file__).with_suffix('.json').write_text(json.dumps(certs,ensure_ascii=False,indent=2),encoding='utf-8')


if __name__=='__main__':main()
