"""Replay full price and damage intervals, without invoking an optimizer.

Rational-function identities and exact real-root isolation check all points
of each interval. Floating LP probes only supplied the candidate bases.
"""
from pathlib import Path
from types import SimpleNamespace
import sys,json
import sympy as sp
from coalition_parametric_probe import mu,with_bounds,Reduced,R


def rational_between(lo,hi):
    if hi is sp.oo:return sp.ceiling(lo)+1
    digits=8
    while True:
        z=R(str(sp.N((lo+hi)/2,digits)))
        if lo<z<hi:return z
        digits*=2


def nonnegative(expr,lo,hi):
    exp=sp.cancel(expr)
    if exp==0:return
    num,den=sp.fraction(exp)
    poles=sp.polys.polytools.real_roots(den,mu) if sp.degree(den,mu)>0 else []
    assert all(not (lo<=r<=hi) for r in poles),(expr,lo,hi,'pole')
    zeros=sp.polys.polytools.real_roots(num,mu) if sp.degree(num,mu)>0 else []
    inside=sorted(set(r for r in zeros if lo<r<hi),key=lambda r:float(sp.N(r,20)))
    edges=[lo]+inside+[hi]
    assert all(a<b for a,b in zip(edges,edges[1:]))
    for left,right in zip(edges,edges[1:]):
        z=rational_between(left,right)
        assert exp.subs(mu,z)>=0,(expr,lo,hi,z)
    # Every interval has constant sign, roots have value zero, and there are
    # no poles on the closed domain. Thus endpoints follow by continuity.


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    model=Reduced(5,R(3,4),R(5,1024),R(1));A,b=with_bounds(model,R(1,20))
    c=model.quality[:,:model.d].T;offset=model.quality[model.d]
    raw=json.loads(Path(__file__).with_name('coalition_parametric_probe.json').read_text())
    certs=[];seen=set()
    for rec in raw:
        key=(rec['lower'],rec['upper'])
        if key not in seen:certs.append(rec);seen.add(key)
    assert len(certs)==7
    lines=['# 少数联盟全区间最优性重验','',
           '2026-09-29。此脚本不调用浮点优化器。读取发现阶段保存的有理函数基，重新构造105个适应性策略约束、个体约束、排序与预算边界；逐段检查原始可行性、非负对偶、stationarity、同目标及全部实根切分后的符号。','',
           '## omega=1：七段覆盖所有非负价格','',
           '| mu 区间 | Q(mu) | 方向 |','|---|---|---|']
    end=sp.S.Zero;lastq=None;certcount=0
    for j,rec in enumerate(certs):
        lo=sp.sympify(rec['lower']);hi=sp.sympify(rec['upper']);assert sp.simplify(lo-end)==0
        ix=rec['basis'];xx=sp.Matrix([sp.sympify(z,locals={'mu':mu}) for z in rec['x']]);yy=sp.Matrix([sp.sympify(z,locals={'mu':mu}) for z in rec['y']])
        assert (A[ix,:]*xx-b[ix,:]).applyfunc(sp.cancel)==sp.zeros(model.d,1)
        assert (A[ix,:].T*yy-c).applyfunc(sp.cancel)==sp.zeros(model.d,1)
        q=sp.cancel((c.T*xx)[0]+offset)
        assert sp.cancel(q-(b[ix,:].T*yy)[0]-offset)==0
        assert sp.cancel(q-sp.sympify(rec['q'],locals={'mu':mu}))==0
        for exp in (*list(b-A*xx),*list(yy)):
            nonnegative(exp,lo,hi);certcount+=1
        for exp in xx:
            den=sp.fraction(sp.cancel(exp))[1]
            assert sp.simplify(den.subs(mu,lo))!=0 and sp.simplify(den.subs(mu,hi))!=0
        sign=1 if j<2 else -1;nonnegative(sign*sp.diff(q,mu),lo,hi)
        if lastq is not None:assert sp.simplify((q-lastq).subs(mu,lo))==0
        lines.append(f'| [{lo}, {hi}] | `{sp.factor(q)}` | {"increasing" if sign==1 else "decreasing"} |')
        end=hi;lastq=q
        print('interval',j+1,'verified',flush=True)
    assert end==R(5504,341)
    for exp in yy:nonnegative(exp,end,sp.oo)
    assert sp.simplify(lastq.subs(mu,end))==R(1,2)
    assert sp.diff(lastq,mu)<0
    # The same final dual stays valid on the entire infeasible tail.
    mustar=(-R(1406)+2*sp.sqrt(518057))/271
    opt=R(12277,38400)+R(79,230400)*sp.sqrt(518057)
    r2=certs[1];q2=sp.sympify(r2['q'],locals={'mu':mu})
    assert sp.simplify(q2.subs(mu,mustar)-opt)==0
    optx=[sp.simplify(sp.sympify(z,locals={'mu':mu}).subs(mu,mustar)) for z in r2['x']]
    lines += ['',f'全部{certcount}个非负条件覆盖所列闭区间。其后同一非负对偶仍成立，给出Q<1/2，故无可行机制。',
              f'全局mu*={mustar}，Q*={opt}≈{float(opt):.12f}。',f'最优(a0,a1,a2,u1,u2)={optx}。','',
              '## omega=0：整个B≥0的闭式','']
    zero=Reduced(5,R(3,4),R(5,1024),R(0));Z,rhs,obj,bounds=zero.owner_zero_matrices(mu)
    for k,(lo,hi) in enumerate(bounds):
        for sign,bound in ((-1,lo),(1,hi)):
            if bound is not None:
                row=[R(0)]*len(bounds);row[k]=sign;Z=Z.col_join(sp.Matrix([row]));rhs=rhs.col_join(sp.Matrix([sign*bound]))
    # Here mu is the damage parameter B; the sixth variable is the price.
    xx=sp.Matrix([R(1,2)-R(33536,9675)*mu]*3+[R(90368,3225)*mu,0,R(1024,5)*mu])
    ix=[3,4,52,7,1,0]
    yy=sp.Matrix([R(69223,38700),R(10759,12900),R(203,774),R(406,3225),R(629,12384),R(131,12384)])
    cc=-sp.Matrix(obj);cut=R(9675,67072)
    assert Z[ix,:].T*yy==cc
    assert (Z[ix,:]*xx-rhs[ix,:]).applyfunc(sp.cancel)==sp.zeros(6,1)
    for exp in list(rhs-Z*xx)+list(yy):nonnegative(exp,sp.S.Zero,cut)
    qq=sp.factor(zero.quality[zero.d]+(cc.T*xx)[0])
    assert sp.cancel(qq-zero.quality[zero.d]-(rhs[ix,:].T*yy)[0])==0
    assert qq.subs(mu,cut)==R(459,512)
    pay=sp.cancel(xx[3]/xx[5]);assert pay==R(353,2580)
    # At B=0 the constant allocation is feasible with this fixed payment.
    orig=sp.Matrix([R(1,2)]*3+[pay,0]+[R(1)])
    assert (zero.G*orig)[0]>=zero.eta
    lines += [f'B∈[0,{cut}]时Q={qq}；达到变量={list(xx)}；对偶支持={ix}，乘子={list(yy)}。',
              f'恢复支付u1={pay},u2=0。B=0单独用相同支付和常数分配。B≥{cut}保持端点设计，达到Bayes上界459/512。','',
              '证据级别：有理函数stationarity和零差恒等式为精确代数；全实区间符号使用SymPy精确实根隔离，不是浮点扫描。一般Bellman等价和经济模型前提不由本脚本独立审计。','']
    Path(__file__).with_suffix('.md').write_text('\n'.join(lines),encoding='utf-8')
    print('Full positive-owner price domain and zero-owner B frontier verified.')


if __name__=='__main__':main()
