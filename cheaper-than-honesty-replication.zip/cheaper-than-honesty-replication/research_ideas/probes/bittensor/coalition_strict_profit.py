"""Exact uniform strict-profit certificates for Paper B's two-member examples."""
from math import comb
from pathlib import Path
import json

import sympy as sp

R = sp.Rational


def payment_basis(n, V):
    """Minority payments t_1,...,t_m and a final constant coordinate."""
    m = n // 2
    zero = lambda: sp.zeros(1, m + 1)
    v1, v0 = [zero() for _ in range(n + 1)], [zero() for _ in range(n + 1)]
    v0[0][-1] = V / n
    v1[n][-1] = V / n
    for k in range(1, m + 1):
        v1[k][k - 1] = 1
        v0[k][-1] = V / (n - k)
        v0[k][k - 1] = -R(k, n - k)
        v1[n - k] = v0[k].copy()
        v0[n - k] = v1[k].copy()
    budget = zero()
    budget[-1] = V
    for k in range(n + 1):
        assert k * v1[k] + (n - k) * v0[k] == budget
        assert v1[n - k] == v0[k]
    return v0, v1


def calculate(n, p, eta):
    V, m = R(1, 2), n // 2
    q = 1 - p
    v0, v1 = payment_basis(n, V)
    zero = lambda: sp.zeros(1, m + 1)
    premium, split, copy = zero(), zero(), zero()
    premium[-1] = V / n
    split_pmf, copy_pmf = [R(0)] * (n + 1), [R(0)] * (n + 1)
    for theta in (0, 1):
        one = p if theta else q
        for out in range(n):
            prob = R(1, 2) * comb(n - 1, out) * one**out * (1 - one)**(n - 1 - out)
            premium -= prob * v1[out + 1]
        for out in range(n - 1):
            prob = R(1, 2) * comb(n - 2, out) * one**out * (1 - one)**(n - 2 - out)
            k = out + 1
            split += prob * (v1[k] + v0[k])
            split_pmf[k] += prob
            for signal in (0, 1):
                pr = prob * (one if signal else 1 - one)
                k = out + 2 * signal
                copy += pr * 2 * (v1[k] if signal else v0[k])
                copy_pmf[k] += pr
    for pmf in (split_pmf, copy_pmf):
        assert sum(pmf) == 1
        assert all(pmf[k] == pmf[n - k] for k in range(n + 1))
    # Honest coalition validation income is 2V/n; split buys no tests, copy buys one.
    split[-1] += 2 * eta - 2 * V / n
    copy[-1] += eta - 2 * V / n
    if n == 5:
        weights, multiplier, claimed_bound = (R(15, 43), R(28, 43)), R(0), R(3, 1000)
        expected_residual = sp.Matrix([[0, R(3, 86), R(341, 110080)]])
    elif n == 7:
        weights, multiplier, claimed_bound = (R(0), R(1)), R(7043855, 1595187), R(1, 125)
        expected_residual = sp.Matrix([[0, R(42490539, 590810000),
                                       R(39276783, 472648000), R(64128401681, 7940486400000)]])
    else:
        raise ValueError(n)
    ic_slack = premium.copy()
    ic_slack[-1] -= eta
    weighted_gain = weights[0] * split + weights[1] * copy
    residual = weighted_gain - multiplier * ic_slack
    assert residual == expected_residual
    assert sum(weights) == 1 and all(w >= 0 for w in weights)
    assert multiplier >= 0 and all(coef >= 0 for coef in residual)
    assert residual[-1] > claimed_bound > 0
    # gain = multiplier*(G-eta) + positive constant + nonnegative minority-payment terms.
    assert weighted_gain - multiplier * ic_slack - expected_residual == zero()
    return {
        "n": n, "c": 2, "p": str(p), "V": str(V), "eta": str(eta),
        "coordinates": [f"v1_{k}" for k in range(1, m + 1)] + ["constant"],
        "split_gain": list(map(str, split)), "copy_gain": list(map(str, copy)),
        "premium": list(map(str, premium)), "mixture_weights": list(map(str, weights)),
        "ic_multiplier": str(multiplier), "residual": list(map(str, residual)),
        "strict_gain_lower_bound": str(claimed_bound),
        "split_count_pmf": list(map(str, split_pmf)), "copy_count_pmf": list(map(str, copy_pmf)),
    }


def main():
    cases = [calculate(5, R(3, 4), R(5, 1024)),
             calculate(7, R(13, 20), R(316809, 89600000))]
    base = Path(__file__).with_suffix("")
    base.with_suffix(".json").write_text(json.dumps(cases, indent=2) + "\n", encoding="utf-8")
    lines = ["# Uniform strict-profit certificates", "",
             "All coefficients below are recomputed by exact finite binomial sums.",
             "Coordinates are minority payments followed by the constant term.",
             "Split casts one vote per miner without testing; copy buys one test and casts both votes with it.",
             "Both unconditional count distributions are exactly reflection-symmetric, so miner holding income is unchanged.", ""]
    for case in cases:
        lines += [f"## n={case['n']}, c=2, p={case['p']}, eta={case['eta']}, V=1/2", "",
                  f"Mixture weights (split, copy): {case['mixture_weights']}.",
                  f"Gain = {case['ic_multiplier']} * (G-eta) + residual {case['residual']}.",
                  f"Every residual coefficient is nonnegative and its constant exceeds {case['strict_gain_lower_bound']} > 0.", ""]
    lines += ["These identities cover every nonnegative anonymous label-symmetric budget-balanced payment with G>=eta.",
              "They are independent of the allocation and the coalition's holding. Individual feasibility implies G>=eta by the manuscript's IC lemma.",
              "Thus each feasible rule in the quoted examples has a strictly profitable coalition deviation; mixing it into any weakly profitable strategy gives the same damage supremum.", ""]
    base.with_suffix(".md").write_text("\n".join(lines), encoding="utf-8")
    for case in cases:
        print(f"Exact certificate: n={case['n']}, strict gain > {case['strict_gain_lower_bound']} for every feasible payment.")


if __name__ == "__main__":
    main()
