"""Figures 1-3 of Paper B.

Figure 1: how far coalitions with 20%, 40% and 70% of the stake can move the vote at p = 3/4, the
          story of Section 1 in the middle row and the tie and mirror thresholds on either side.
Figure 2: the large-subnet frontier of Theorem 4.1 at p = 3/4 and tolerance 1/10, the majority rule
          under the takeover of Proposition 3.2, and the finite best rules of Section 5 (saved LP values,
          research_ideas/probes/bittensor/numerics/phase_finite_lp.csv).
Figure 3: where the takeover pays in Bittensor's reward code (saved one-round values,
          research_ideas/probes/bittensor/numerics/yuma_phase_strategies.csv) against 31 times the tie threshold.
"""
import csv
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
import hz_figstyle as hz  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import Patch  # noqa: E402

HERE = Path(__file__).resolve().parent
NUM = HERE.parents[1] / "probes" / "bittensor" / "numerics"
hz.apply()


def save(fig, name):
    hz.save(fig, str(HERE / f"{name}.pdf"))
    fig.savefig(HERE / f"{name}.png", bbox_inches="tight", pad_inches=0.03, dpi=220)
    plt.close(fig)


# ---- Figure 1: how far a coalition can move the vote (p = 3/4) -------------------------------
# Each bar spans the better miner's average vote share as the coalition splits its own votes:
# from the honest support (1 - gamma) p (whole coalition for the worse miner) to (1 - gamma) p + gamma.
p = 0.75
rows = [(0.2, "20% of the stake", "cannot reach a tie"),
        (0.4, "40% of the stake", "can force a tie"),
        (0.7, "70% of the stake", "can mirror the vote")]
fig, ax = plt.subplots(figsize=(3.3, 1.75))
for x, label in [(1 - p, "mirror"), (0.5, "tie"), (p, "honest")]:
    ax.axvline(x, color=hz.GUIDE, lw=0.7, ls=(0, (3, 2)) if x != 0.5 else "-", zorder=0)
    ax.text(x, 3.02, label, ha="center", va="bottom", fontsize=6.8, color="0.25")
for y, (g, _, verdict) in zip([2, 1, 0], rows):
    lo, hi = (1 - g) * p, (1 - g) * p + g
    ax.plot([lo, hi], [y, y], color="0.72", lw=7.5, solid_capstyle="butt", zorder=2)
    ax.plot([p], [y], "o", ms=4.2, mfc="white", mec=hz.INK, mew=0.9, zorder=4)
    ax.plot([lo], [y], "o", ms=4.2, mfc=hz.INK, mec=hz.INK, zorder=4)
    ax.text(1.02, y, verdict, ha="left", va="center", fontsize=6.8, color="0.10", clip_on=False)
ax.plot([0.5], [1], "D", ms=3.8, mfc=hz.INK, mec="white", mew=0.5, zorder=5)
ax.plot([1 - p], [0], "D", ms=3.8, mfc=hz.INK, mec="white", mew=0.5, zorder=5)
ax.set_yticks([2, 1, 0])
ax.set_yticklabels([r[1] for r in rows])
ax.set_ylim(-0.6, 2.95)
ax.set_xlim(0, 1)
ax.set_xticks([0, 0.25, 0.5, 0.75, 1])
ax.set_xticklabels(["0", "1/4", "1/2", "3/4", "1"])
ax.set_xlabel("better miner's share of the vote")
ax.grid(False)
ax.tick_params(axis="y", length=0)
hz.style_ticklabels(ax)
save(fig, "reach")

# ---- Figure 2: frontier at p = 3/4, tolerance 1/10 -----------------------------------------
p, B = 0.75, 0.1
g1, g2 = 1 - 1 / (2 * p), 2 - 1 / p
fig, ax = plt.subplots(figsize=(3.3, 2.15))
eps = 1e-3
ax.plot([0, g1 - eps], [1, 1], color=hz.INK, lw=1.4, label="best any rule can do (large subnets)", zorder=3)
ax.plot([g1 + eps, g2 - eps], [0.5 + B, 0.5 + B], color=hz.INK, lw=1.4, zorder=3)
ax.plot([g2 + eps, 1], [0.5 + B / 2, 0.5 + B / 2], color=hz.INK, lw=1.4, zorder=3)
ax.plot([0, g1 - eps], [1, 1], color=hz.INK, lw=1.0, ls=(0, (4, 2)), zorder=2)
ax.plot([g1 + eps, 0.5], [0, 0], color=hz.INK, lw=1.0, ls=(0, (4, 2)), zorder=2,
        label="majority rule under the takeover")
for x in (g1, g2):
    ax.axvline(x, color=hz.GUIDE, lw=0.6, ls=(0, (2, 2)), zorder=1)
ax.axhline(0.5, color=hz.GUIDE, lw=0.6, zorder=1)
lp = [r for r in csv.DictReader(open(NUM / "phase_finite_lp.csv", encoding="utf-8")) if abs(float(r["p"]) - p) < 1e-12]
marks = {11: ("o", "white"), 31: ("s", "white"), 51: ("^", hz.INK)}
seen = set()
for r in lp:
    n = int(r["n"])
    key = (n, int(r["c"]))
    if key in seen:
        continue
    seen.add(key)
    m, fc = marks[n]
    ax.plot(float(r["actual_gamma"]), float(r["Q_floating_LP"]), m, ms=4.0, mfc=fc, mec=hz.INK, mew=0.8,
            zorder=5, label=f"best rule, {n} validators" if n not in {k[0] for k in seen - {key}} else None)
ax.text(g1, 1.075, "tie threshold", ha="center", va="bottom", fontsize=6.8, color="0.25")
ax.text(g2, 1.075, "mirror threshold", ha="center", va="bottom", fontsize=6.8, color="0.25")
ax.text(0.99, 0.485, "even split", ha="right", va="top", fontsize=6.8, color="0.35")
ax.set_xlim(0, 1)
ax.set_ylim(-0.03, 1.13)
ax.set_xticks([0, 1 / 3, 0.5, 2 / 3, 1])
ax.set_xticklabels(["0", "1/3", "1/2", "2/3", "1"])
ax.set_yticks([0, 0.25, 0.5, 0.55, 0.6, 0.75, 1])
ax.set_yticklabels(["0", "", "0.5", "", "0.6", "", "1"])
ax.set_xlabel(r"coalition's share of the stake, $\gamma$")
ax.set_ylabel("quality")
handles, labels = ax.get_legend_handles_labels()
ax.legend(handles, labels, loc="center left", bbox_to_anchor=(0.01, 0.24), fontsize=6.3, frameon=False,
          handlelength=2.0, borderaxespad=0.2)
hz.style_ticklabels(ax)
save(fig, "frontier")

# ---- Figure 3: the takeover in Bittensor's code ---------------------------------------------
ys = [r for r in csv.DictReader(open(NUM / "yuma_phase_strategies.csv", encoding="utf-8"))
      if r["strategy"] == "shared_majority_reverse" and r["ownership_total_miner0"] == "0.0"
      and r["mode"] == "legacy_alpha_one"]
ps = sorted({float(r["p"]) for r in ys})
cs = list(range(1, 16))
grid = np.zeros((len(cs), len(ps)))
for r in ys:
    grid[int(r["coalition_c"]) - 1, ps.index(float(r["p"]))] = 1.0 if float(r["profit_gain"]) > 1e-10 else 0.0
fig, ax = plt.subplots(figsize=(3.3, 2.15))
dp = ps[1] - ps[0]
ax.pcolormesh(np.r_[np.array(ps) - dp / 2, ps[-1] + dp / 2], np.arange(0.5, 16.5, 1.0), grid,
              cmap=plt.matplotlib.colors.ListedColormap(["white", "0.72"]), vmin=0, vmax=1,
              edgecolors="0.93", linewidth=0.3, shading="flat")
pp = np.linspace(0.5, 1.0, 400)
ax.plot(pp, 31 * (1 - 1 / (2 * pp)), color=hz.INK, lw=1.2, label=r"tie threshold, $31(1-1/(2p))$")
ax.set_xlim(0.5, 1.0)
ax.set_ylim(0.5, 15.5)
ax.set_yticks([1, 5, 10, 15])
ax.set_xticks([0.5, 0.6, 0.7, 0.8, 0.9, 1.0])
ax.set_xticklabels(["50%", "60%", "70%", "80%", "90%", "100%"])
ax.set_xlabel("accuracy of one test, $p$")
ax.set_ylabel("validators in the coalition")
ax.grid(False)
ax.legend(handles=[Patch(facecolor="0.72", edgecolor="0.93", label="takeover pays in that round"),
                   ax.get_lines()[0]],
          loc="upper left", fontsize=6.5, frameon=False, handlelength=1.6, borderaxespad=0.3)
hz.style_ticklabels(ax)
save(fig, "yuma_takeover")
print("figures written to", HERE)
