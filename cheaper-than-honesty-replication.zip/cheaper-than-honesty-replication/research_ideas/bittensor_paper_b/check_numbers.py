"""Recompute every number quoted in the Paper B abstract and introduction (draft.md).

Exact numbers use the formulas in research_ideas/bittensor_phase_repair_20260929.md
(gamma_1 = 1 - 1/(2p), gamma_2 = 2 - 1/p, frontier 1 / 1/2+B / 1/2+B/2). Finite-subnet
and Bittensor-code numbers are read from the saved data files, not recomputed by solvers.
This script checks that the prose quotes those sources correctly; it proves nothing.
"""
import csv
import json
import math
from fractions import Fraction as F
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NUM = ROOT / "probes" / "bittensor" / "numerics"
PROBES = ROOT / "probes" / "bittensor"

results = []


def check(label, ok, detail=""):
    results.append(bool(ok))
    print(f"{'OK ' if ok else 'BAD'} {label}" + (f": {detail}" if detail else ""))


def tie(p):
    return 1 - 1 / (2 * p)


def mirror(p):
    return 2 - 1 / p


def cap(gamma, p, B):
    """Large-subnet frontier, noncritical gamma."""
    if gamma < tie(p):
        return F(1)
    if gamma < mirror(p):
        return min(F(1), F(1, 2) + B)
    return min(F(1), F(1, 2) + B / 2)


# --- Story: p = 3/4, coalition 40% of the stake -------------------------------------------
p, g = F(3, 4), F(2, 5)
honest_better, honest_worse = (1 - g) * p, (1 - g) * (1 - p)
check("honest support 45% / 15%", (honest_better, honest_worse) == (F(9, 20), F(3, 20)))
check("honest vote overall about 75% / 25%", honest_better + g * p == F(3, 4))
check("takeover: worse miner draws 55%", honest_worse + g == F(11, 20))
check("a quarter of honest votes go the wrong way", 1 - p == F(1, 4))
cut = F(35, 100)
check("band cutoffs 35/65 separate honest votes and the coalition's reach",
      (1 - p) < cut < honest_better, f"{1 - p} < {cut} < {honest_better}")
check("tie: 5 points to the better miner, 35 to the worse", honest_better + F(5, 100) == F(1, 2)
      and F(5, 100) + F(35, 100) == g)
check("coalition of 40% lies between the thresholds", tie(p) < g < mirror(p),
      f"{tie(p)} < {g} < {mirror(p)}")
reach = {gam: ((1 - gam) * p, (1 - gam) * p + gam) for gam in (F(1, 5), F(2, 5), F(7, 10))}
check("Figure 1: 20% cannot reach a tie, 40% can, 70% can reach 1-p",
      reach[F(1, 5)][0] > F(1, 2) and reach[F(2, 5)][0] <= F(1, 2) < reach[F(7, 10)][0] + 1
      and reach[F(7, 10)][0] <= 1 - p and reach[F(2, 5)][0] > 1 - p,
      f"left ends {[str(v[0]) for v in reach.values()]}")
check("Figure 1: honest testing sits at p in every row, inside every bar",
      all(lo <= p <= hi for lo, hi in reach.values()))

# --- Thresholds ---------------------------------------------------------------------------
check("p=3/4: one third and two thirds", (tie(F(3, 4)), mirror(F(3, 4))) == (F(1, 3), F(2, 3)))
check("p=3/5: one sixth and one third", (tie(F(3, 5)), mirror(F(3, 5))) == (F(1, 6), F(1, 3)))
check("p=9/10: 44% and 89%", (tie(F(9, 10)), mirror(F(9, 10))) == (F(4, 9), F(8, 9)),
      f"{float(tie(F(9, 10))):.4f}, {float(mirror(F(9, 10))):.4f}")
check("mirror threshold is twice the tie threshold", all(mirror(x) == 2 * tie(x)
      for x in (F(3, 5), F(3, 4), F(9, 10), F(13, 20))))
check("tie threshold below 1/2 for p<1, equal at p=1", tie(F(99, 100)) < F(1, 2) and tie(F(1)) == F(1, 2))
grid = [F(k, 100) for k in range(51, 100)]
check("noisier tests, smaller coalition: tie threshold rises with p",
      all(tie(a) < tie(b) for a, b in zip(grid, grid[1:])))

# --- Frontier with a ten-point tolerance --------------------------------------------------
B = F(1, 10)
check("tolerance 10 points: caps 60% and 55%",
      (cap(F(1, 2), F(3, 4), B), cap(F(4, 5), F(3, 4), B)) == (F(3, 5), F(11, 20)))
check("rule shares: twice the tolerance, the tolerance", (min(1, 2 * B), min(1, B)) == (F(1, 5), F(1, 10)))

# --- Small subnets: saved zero-ownership full-price LP values (floating HiGHS) ------------
rows = list(csv.DictReader(open(NUM / "phase_finite_lp.csv", encoding="utf-8")))


def lp(n, c, pp):
    hit = [r for r in rows if int(r["n"]) == n and int(r["c"]) == c and abs(float(r["p"]) - pp) < 1e-12]
    return float(hit[0]["Q_floating_LP"]), float(hit[0]["B"]), hit[0]["eta_convention"]


q51, b51, eta51 = lp(51, 12, 0.6)
check("p=3/5, n=51, c=12: about 65% against a 60% limit",
      round(100 * q51) == 65 and cap(F(12, 51), F(3, 5), F(1, 10)) == F(3, 5) and b51 == 0.1,
      f"Q={q51:.6f}, eta={eta51}")
q31, b31, _ = lp(31, 13, 0.75)
check("p=3/4, n=31, c=13: within 0.2 points of the 60% limit",
      abs(q31 - 0.6) < 0.002 and cap(F(13, 31), F(3, 4), F(1, 10)) == F(3, 5), f"Q={q31:.6f}")

# --- Three cutoffs (n=7, c=2, p=13/20, B=3/100): exact values from the saved certificate ---
blob = (PROBES / "coalition_zero_owner.json").read_text(encoding="utf-8")
q_all = F(291873700680756771811, 507378235920944021700)
q_two = F(17602209012262848289, 30634136142275200000)
check("certificate values present in coalition_zero_owner.json",
      "291873700680756771811/507378235920944021700" in blob and "17602209012262848289/30634136142275200000" in blob)
check("three cutoffs beat every rule with at most two, slightly", q_all > q_two,
      f"{float(q_all):.6f} vs {float(q_two):.6f}, gap {float(q_all - q_two) * 100:.3f} points")

# --- Bittensor's code: n = 31, all-or-nothing weights, one round -------------------------
yrows = list(csv.DictReader(open(NUM / "yuma_phase_strategies.csv", encoding="utf-8")))
rev = [r for r in yrows if r["strategy"] == "shared_majority_reverse" and r["ownership_total_miner0"] == "0.0"]
ps = sorted({r["p"] for r in rev}, key=float)
check("25 test accuracies from 51% to 99%", len(ps) == 25 and ps[0] == "0.51" and ps[-1] == "0.99")
check("the takeover buys a test for every member", all(int(r["signals_bought"]) == int(r["coalition_c"]) for r in rev))
onset_ok, harm_ok = True, True
for mode in ("legacy_alpha_one", "default_fixed_alpha"):
    for pv in ps:
        rr = [r for r in rev if r["mode"] == mode and r["p"] == pv]
        prof = sorted(int(r["coalition_c"]) for r in rr if float(r["profit_gain"]) > 1e-10)
        line = math.ceil(31 * tie(F(rr[0]["p_exact"])))
        if prof:
            onset_ok &= prof == list(range(prof[0], 16)) and abs(prof[0] - line) <= 1
            harm_ok &= all(float(r["quality_damage"]) > 0 for r in rr if int(r["coalition_c"]) in prof)
        else:
            onset_ok &= line >= 16  # threshold beyond the largest minority; nothing profits
check("profitable coalitions are exactly those from the tie threshold (give or take one) up to 15",
      onset_ok)
check("every profitable takeover pushes pay toward the worse miner", harm_ok)


def row(mode, pv, c):
    return [r for r in rev if r["mode"] == mode and r["p"] == pv and int(r["coalition_c"]) == c][0]


a1, d1 = row("legacy_alpha_one", "0.61", 8), row("default_fixed_alpha", "0.61", 8)
gain1 = float(a1["deviation_coalition_validator_income"]) / float(a1["reference_coalition_validator_income"]) - 1
gaind = float(d1["deviation_coalition_validator_income"]) / float(d1["reference_coalition_validator_income"]) - 1
check("p=61%: tie threshold 18% of the stake", round(100 * float(tie(F(61, 100)))) == 18,
      f"{float(tie(F(61, 100))):.4f}")
check("8 validators are a quarter of the stake", round(100 * 8 / 31) == 26, f"{8 / 31:.4f}")
check("memory off: pay up 31%", round(100 * gain1) == 31, f"{100 * gain1:.2f}%")
check("better miner's share 89% -> 47%",
      (round(100 * float(a1["reference_quality"])), round(100 * float(a1["deviation_quality"]))) == (89, 47),
      f"{float(a1['reference_quality']):.4f} -> {float(a1['deviation_quality']):.4f}")
check("default memory: pay up 3% in that round, same harm",
      round(100 * gaind) == 3 and abs(float(d1["quality_damage"]) - float(a1["quality_damage"])) < 1e-12,
      f"{100 * gaind:.2f}%, harm {float(d1['quality_damage']):.4f}")

# ================= Sections 2-8 and appendices =================
import sympy as sp
from math import comb


def q_maj(n, pp):
    m = n // 2
    return sum(comb(n, k) * pp**k * (1 - pp)**(n - k) for k in range(m + 1, n + 1))


def gstar(n, pp, V):
    return V * (2 * pp - 1) * (q_maj(n, pp) - pp) / (2 * n * pp * (1 - pp))


# Section 3: coalition's share of the validators' budget under the takeover
pp, gg = F(3, 4), F(2, 5)
check("Sec 3: share rises from 2/5 to 8/11", gg / (gg + (1 - gg) * (1 - pp)) == F(8, 11), f"{float(F(8, 11)):.4f}")
P, Gm = sp.symbols("p gamma", positive=True)
g1s = 1 - 1 / (2 * P)
check("App B: gamma+(1-gamma)q = 1/2 + p(gamma-gamma_1)",
      sp.simplify(Gm + (1 - Gm) * (1 - P) - (sp.Rational(1, 2) + P * (Gm - g1s))) == 0)
Vs = sp.symbols("V", positive=True)
check("App B: takeover pay gain identity",
      sp.simplify(Vs * Gm / (Gm + (1 - Gm) * (1 - P)) - Vs * Gm
                  - Vs * Gm * (1 - Gm) * P / (Gm + (1 - Gm) * (1 - P))) == 0)

# Lemma 2.1: pairwise coefficient identity, n = 5, 7, 9
ok = True
for n in (5, 7, 9):
    m = n // 2
    Q_ = 1 - P
    h = lambda j: sp.Rational(1, 2) * sp.binomial(n - 1, j) * (P**j * Q_**(n - 1 - j) + Q_**j * P**(n - 1 - j))
    for k in range(1, m + 1):
        lhs = h(k - 1) - sp.Rational(k, n - k) * h(k)
        rhs = sp.Rational(1, 2) * sp.binomial(n - 1, k - 1) * (2 * P - 1) * (Q_**(k - 1) * P**(n - k - 1) - P**(k - 1) * Q_**(n - k - 1))
        ok &= sp.expand(lhs - rhs) == 0
check("App A: coefficient identity h_{k-1}-k/(n-k)h_k for n=5,7,9", ok)
ok = all(gstar(n, F(3, 4), F(1, 2)) == F(1, 2) * F(1, 2) * (q_maj(n, F(3, 4)) - F(3, 4)) / (2 * n * F(3, 16))
         for n in (3, 5, 7))
check("Lemma 2.1: G* formula evaluates", ok)

# Appendix C: coalition vote counts inside [0, c] exactly beyond the thresholds; mirror pay identity
check("App C: 1/2-(1-gamma)p>0 iff gamma>gamma_1",
      sp.simplify((sp.Rational(1, 2) - (1 - Gm) * P) - P * (Gm - g1s)) == 0)
check("App C: gamma-(d+gamma q) = p(gamma-gamma_2)",
      sp.simplify(Gm - (2 * P - 1 + Gm * (1 - P)) - P * (Gm - (2 - 1 / P))) == 0)
W1, W0 = sp.symbols("W1 W0")
d_ = 2 * P - 1
check("App C: mirror pay identity",
      sp.expand((d_ + Gm * (1 - P)) * W1 + (Gm - d_ - Gm * (1 - P)) * W0
                - (Gm * (P * W1 + (1 - P) * W0) + (1 - Gm) * d_ * (W1 - W0))) == 0)
check("App C: (d/2)(W1-W0) = pW1+qW0-(W1+W0)/2",
      sp.expand(d_ / 2 * (W1 - W0) - (P * W1 + (1 - P) * W0 - (W1 + W0) / 2)) == 0)

# Example 5.3
g5 = gstar(5, F(3, 4), F(1, 2))
check("Ex 5.3: G*_5 = 5/256 and eta = 5/1024 is a quarter", g5 == F(5, 256) and F(5, 1024) == g5 / 4)
check("Ex 5.3: A_5 = 459/512, A_5 - 1/2 = 203/512", q_maj(5, F(3, 4)) == F(459, 512) and q_maj(5, F(3, 4)) - F(1, 2) == F(203, 512))
slope = F(203, 512) * F(67072, 9675)
check("Ex 5.3: slope about 2.75, saturation about 0.144",
      round(float(slope), 2) == 2.75 and round(float(F(9675, 67072)), 3) == 0.144, f"{float(slope):.4f}, {float(F(9675, 67072)):.4f}")
check("Ex 5.3: coalition share 2/5 lies between the thresholds", tie(F(3, 4)) < F(2, 5) < mirror(F(3, 4)))
qh = F(12277, 38400) + 79 * sp.sqrt(518057) / 230400
mu_star = (2 * sp.sqrt(518057) - 1406) / 271
piece2 = (525373 * mu_star + 5726468) / (230400 * (3 * mu_star + 44))
check("Ex 5.3: holdings value about 0.5665 and equals the certificate piece at mu*",
      round(float(qh), 4) == 0.5665 and sp.simplify(piece2 - qh) == 0, f"{float(qh):.6f}, mu*={float(mu_star):.6f}")
u1 = F(90368, 3225) / F(1024, 5)
check("Ex 5.3: recovered payment z/mu = 353/2580", u1 == F(353, 2580))

# Proposition 5.4
g7 = gstar(7, F(13, 20), F(1, 2))
check("Prop 5.4: eta = G*_7/2 = 316809/89600000", g7 / 2 == F(316809, 89600000))
check("Prop 5.4: gap about 0.07 points", round(float(q_all - q_two) * 100, 2) == 0.07)

# Section 5: how small is small
vals = {(n, c): lp(n, c, 0.6)[0] for n, c in ((11, 2), (31, 7), (51, 12))}
check("Sec 5: p=3/5 best qualities 0.753, 0.672, 0.654",
      [round(vals[k], 3) for k in ((11, 2), (31, 7), (51, 12))] == [0.753, 0.672, 0.654])
shares = [F(2, 11), F(7, 31), F(12, 51)]
check("Sec 5: coalitions of 18% to 24%, all between the thresholds at p=3/5",
      round(100 * float(min(shares))) == 18 and round(100 * float(max(shares))) == 24
      and all(tie(F(3, 5)) < s < mirror(F(3, 5)) for s in shares))
check("Sec 5: p=3/4, 51 validators within 0.2 points", abs(lp(51, 22, 0.75)[0] - 0.6) < 0.002)

# Section 6 identities
Pi, rho, Lam = sp.symbols("Pi rho Lambda", positive=True)
fix = (1 - rho) / 2 + rho * Lam * Pi / (1 + (Lam - 1) * Pi)
check("App E: (1+rho)/2 - F(Pi) = rho(1-Pi)/(1+(Lambda-1)Pi)",
      sp.simplify((1 + rho) / 2 - fix - rho * (1 - Pi) / (1 + (Lam - 1) * Pi)) == 0)
pi_, G_, eta_ = sp.symbols("pi G eta", real=True)
Rf = (2 * (P - pi_) * G_ / d_ - eta_) / (P - d_ * pi_)
check("App E: derivative of R(pi)",
      sp.simplify(sp.diff(Rf, pi_) + (4 * P * (1 - P) * G_ / d_ + d_ * eta_) / (P - d_ * pi_)**2) == 0)
check("App E: limit factor 2(p-(1+rho)/2)/d = (d-rho)/d",
      sp.simplify(2 * (P - (1 + rho) / 2) / d_ - (d_ - rho) / d_) == 0)

# Section 7
check("Sec 7: 31 x tie threshold = 5.6 at 61%, 10.3 at 75%",
      (round(float(31 * tie(F(61, 100))), 1), round(float(31 * tie(F(3, 4))), 1)) == (5.6, 10.3))
g10, g11 = (float(row("legacy_alpha_one", "0.75", c)["profit_gain"]) for c in (10, 11))
check("Sec 7: at p=3/4, 10 lose and 11 gain", g10 < 0 < g11, f"{g10:.5f}, {g11:.5f}")
rev_all = [r for r in yrows if r["strategy"] == "shared_majority_reverse"]
diff = max(abs(float(a["profit_gain"]) - float(b["profit_gain"]))
           for a in rev_all if a["ownership_total_miner0"] == "0.0"
           for b in rev_all if b["ownership_total_miner0"] == "0.2" and b["mode"] == a["mode"]
           and b["p"] == a["p"] and b["coalition_c"] == a["coalition_c"])
check("Sec 7: a fifth of one miner's emission leaves the gains unchanged", diff < 1e-9, f"max diff {diff:.2e}")
check("App F: no grid point within 1e-10 of zero gain",
      min(abs(float(r["profit_gain"])) for r in yrows) > 1e-10)

print(f"\n{sum(results)}/{len(results)} checks passed")
raise SystemExit(0 if all(results) else 1)
